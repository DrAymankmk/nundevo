<?php


namespace App\Http\Controllers\AdminPanel\Nursing;

use App\Http\Controllers\Controller;
use App\Models\Clinic;
use App\Models\Drugs;
use App\Models\Emergency;
use App\Models\PatientService;
use App\Models\ReservationDrug;
use App\Models\User;
use App\Models\VitalSigns;
use DateTime;
use Illuminate\Http\Request;

class NursingRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $currentDate = now()->toDateString();
        if (auth()->user()->is_manager == 1) {
            $nurseServises = PatientService::with(['services', 'user', 'doctor', 'nurse'])
                ->where('invoice_id', '!=', null)
                ->where('clinic_id', auth()->user()->parent_id)
                ->where(function ($query) {
                    $query->where('type', 3)
                        ->orWhere('type', 1);
                })
                ->whereDate('created_at', $currentDate)
                ->groupBy('user_id')
                ->get();
        } else {
            $nurseServices = PatientService::with(['services', 'user', 'doctor', 'nurse'])
                ->where('invoice_id', '!=', null)
                ->where('clinic_id', auth()->user()->parent_id)
                ->where('point_id', auth()->user()->nursing_point_id)
                ->where(function ($query) {
                    $query->where('type', 3)
                        ->orWhere('type', 1);
                })
                ->where(function ($query) {
                    $query->where('nurse_id', auth()->user()->id)
                        ->orWhereNull('nurse_id');
                })
                ->whereDate('created_at', $currentDate)
                ->groupBy('user_id')
                ->get();
        }
        $data['patients'] = User::where('status', 1)->orderBy('id', 'desc')->get();

        return view('nursing.nursing_requests', compact('nurseServices','data'));
    }

    public function details($id)
    {

        $currentDate = now()->toDateString();
        if (auth()->user()->is_manager == 1) {
            $nurseServises = PatientService::with(['services', 'user', 'doctor', 'nurse'])
                ->where('invoice_id', '!=', null)
                ->where('clinic_id', auth()->user()->parent_id)
                ->where('user_id',$id)
                ->where(function ($query) {
                    $query->where('type', 3)
                        ->orWhere('type', 1);
                })
                ->orWhereDate('created_at', $currentDate)

                ->get();
        } else {
            $nurseServices = PatientService::with(['services', 'user', 'doctor', 'nurse'])
                ->where('invoice_id', '!=', null)
                ->where('clinic_id', auth()->user()->parent_id)
                ->where('point_id', auth()->user()->nursing_point_id)
                ->where('user_id',$id)
                ->where(function ($query) {
                    $query->where('type', 3)
                        ->orWhere('type', 1);
                })
                ->where(function ($query) {
                    $query->where('nurse_id', auth()->user()->id)
                        ->orWhereNull('nurse_id');
                })
                ->whereDate('created_at', $currentDate)
                ->get();
        }

        return view('nursing.nursing_requests_Details', compact('nurseServises'));
    }
    public function vitalSigns($id)
    {

        $nonVitalSignsData=null;
        $vitalSignsData = PatientService::with(['user', 'doctor'])
            ->join('vital_signs', 'patient_services.reservation_id', '=', 'vital_signs.reservation_id')
            ->where('patient_services.reservation_id', $id)
            ->select('patient_services.*', 'vital_signs.*')
            ->first();

        if ($vitalSignsData === null) {
            $nonVitalSignsData = PatientService::with(['user', 'doctor'])
                ->where('reservation_id', $id)
                ->first();
        }
        $drugs = ReservationDrug::with('drugs')->where('reservation_id', $id)->get();
        return view('nursing.nursing_requestsvitalSigns', compact('vitalSignsData', 'nonVitalSignsData', 'drugs', 'id'));
    }

    public function vitalSignsUpdate(Request $request, $id)
    {

        $vitalSign = VitalSigns::updateOrCreate(
            ['reservation_id' => $id], // Find record by ID
            array_merge($request->all(), [
                'clinic_id' => auth()->user()->parent_id,
                'reservation_id' => $id,
            ])
        );
        return redirect()->route('nursing-requests.index');
    }

    public function confirmedService(Request $request)
    {

        $patientConfirmed = PatientService::findOrFail($request->patientServiceId);
        $patientConfirmed->update([
            'nurse_id' => auth()->user()->id,
        ]);
        return response()->json([], 200);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function search(Request $request)
    {
        $isManager = auth()->user()->is_manager == 1;
        $nurseServices = PatientService::with(['services', 'user', 'doctor', 'nurse'])
            ->where('invoice_id', '!=', null)
            ->where('clinic_id', auth()->user()->parent_id);

        if ($isManager) {
            $nurseServices->where('type', 3);
        } else {
            $nurseServices->where('point_id', auth()->user()->nursing_point_id)
                ->where('type', 3)
                ->where(function ($query) {
                    $query->where('nurse_id', auth()->user()->id)
                        ->orWhereNull('nurse_id');
                });
        }

        $searchQuery = $request->query('query');

        $nurseServices->where(function ($query) use ($searchQuery) {
            $query->whereHas('user', function ($userQuery) use ($searchQuery) {
                $userQuery->where('name', 'like', '%' . $searchQuery . '%')
                    ->orWhere('ID_Number', 'like', '%' . $searchQuery . '%')
                    ->orWhere('phone', 'like', '%' . $searchQuery . '%');
            })
                ->orWhereHas('services', function ($servicesQuery) use ($searchQuery) {
                    $servicesQuery->where('code', 'like', '%' . $searchQuery . '%');
                });
        });

        $results = $nurseServices->get();
        return response()->json(['nurseServices' => $results]);
    }


    public function filter(Request $request)
    {
        $fromDate = DateTime::createFromFormat('d/m/Y', $request->fromDate);
        $toDate = DateTime::createFromFormat('d/m/Y', $request->toDate);
        // Format the dates as 'Y-m-d' (e.g., 2023-12-04)
        $formattedFromDate = $fromDate->format('Y-m-d');
        $formattedToDate = $toDate->format('Y-m-d');

        $user = auth()->user();
        $commonQuery = PatientService::with(['services', 'user', 'doctor', 'nurse'])
            ->where('invoice_id', '!=', null)
            ->where('clinic_id', $user->parent_id)
            ->where('type', 3)
            ->whereBetween('created_at', [$formattedFromDate, $formattedToDate]);

        if ($user->is_manager == 0) {
            $nurseServices = $commonQuery
                ->where('point_id', $user->nursing_point_id)
                ->where(function ($query) use ($user) {
                    $query->where('nurse_id', $user->id)
                        ->orWhereNull('nurse_id');
                })
                ->get();
        } else {
            $nurseServices = $commonQuery->get();
        }

        return response()->json(['nurseServices' => $nurseServices]);
    }
}
