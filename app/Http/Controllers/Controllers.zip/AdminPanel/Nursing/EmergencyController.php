<?php


namespace App\Http\Controllers\AdminPanel\Nursing;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Nursing\EmergencyRequest;
use App\Http\Requests\Admin\Nursing\PatientEmergencyRequest;
use App\Models\City;
use App\Models\Clinic;
use App\Models\Drugs;
use App\Models\Emergency;
use App\Models\User;
use App\Models\VitalSigns;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class EmergencyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $emergency = Emergency::with(['user', 'doctors'])->where('clinic_id', auth()->user()->parent_id)->get();
        $all_nurses = Clinic::where('app_type', 8)->where('parent_id', auth()->user()->parent_id)->get();
        return view('nursing.emergency_index', compact('emergency', 'all_nurses'));
    }

    public function saveNote(Request $request)
    {
        $emergency = Emergency::find($request->note_id);
        $emergency->update([
            'notes' => $request->note_content,
        ]);
        return response()->json([], 200);
    }
    public function normalExit(Request $request)
    {
        $emergency = Emergency::find($request->id);
        $emergency->update([
            'type' => 1,
            'exit_date' => now(),
        ]);
        return response()->json([], 200);
    }
    public function ambulanceExit(Request $request)
    {
        $emergency = Emergency::find($request->id);
        $emergency->update([
            'type' => 2,
            'exit_date' => now(),
            'nurse_id' => $request->selectedNurseId,
        ]);
        return response()->json([], 200);
    }

    public function filter(Request $request)
    {
        $fromDate = DateTime::createFromFormat('d/m/Y', $request->fromDate);
        $toDate = DateTime::createFromFormat('d/m/Y', $request->toDate);

        // Format the dates as 'Y-m-d' (e.g., 2023-12-04)
        $formattedFromDate = $fromDate->format('Y-m-d');
        $formattedToDate = $toDate->format('Y-m-d');

        $emergency = Emergency::with(['user', 'doctors'])
            ->where('clinic_id', auth()->user()->parent_id)
            ->where(function ($query) use ($formattedFromDate, $formattedToDate) {
                $query->whereBetween('enter_date', [$formattedFromDate, $formattedToDate])
                    ->orWhereBetween('exit_date', [$formattedFromDate, $formattedToDate]);
            })
            ->get();

        return response()->json(['emergency' => $emergency]);
    }

    public function search(Request $request)
    {

        $emergency = Emergency::with(['user', 'doctors'])
            ->where('clinic_id', auth()->user()->parent_id);


        $searchQuery = $request->query('query');

        $emergency->where(function ($query) use ($searchQuery) {
            $query->whereHas('user', function ($userQuery) use ($searchQuery) {
                $userQuery->where('name', 'like', '%' . $searchQuery . '%')
                    ->orWhere('ID_Number', 'like', '%' . $searchQuery . '%');
            });
        });

        $results = $emergency->get();
        return response()->json(['emergency' => $results]);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users = User::get();
        $doctors = Clinic::where('app_type', 3)->where('parent_id', auth()->user()->parent_id)->get();
        $nurses = Clinic::where('app_type', 8)->where('parent_id', auth()->user()->parent_id)->get();
        $drugs = Drugs::get();
        return view('nursing.emergency', compact('users', 'doctors', 'nurses', 'drugs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(EmergencyRequest $request)
    {

        $emergency = $request->except([
            'heat', 'pulse', 'blood_pressure', 'pain_rate', 'weight', 'height', 'breathing',
            'oxygen_ratio', 'body_mass_rate', 'FBS', 'RBS', 'doctor_id', 'nurse_id', 'drugs_id'
        ]);
        $emergency['clinic_id'] = auth()->user()->parent_id;
        $emergency['enter_date'] = now();
        $add_emergency = Emergency::create($emergency);
        $vitalSign = $request->except([
            'nurse_id', 'notes', 'enter_date',
            'exit_date', 'type', 'doctor_id', 'nurse_id', 'drugs_id'
        ]);
        $vitalSign['clinic_id'] = auth()->user()->parent_id;
        $vitalSign['emergency_id'] = $add_emergency->id;
        VitalSigns::create($vitalSign);
        $add_emergency->doctors()->sync($request->input('doctor_id'));
        $add_emergency->nurses()->sync($request->input('nurse_id'));
        $add_emergency->drugs()->sync($request->input('drugs_id'));
        return redirect()->route('emergency.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Emergency  $emergency
     * @return \Illuminate\Http\Response
     */
    public function show(Emergency $emergency)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Emergency  $emergency
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $emergency = Emergency::with(['user', 'doctors', 'vitalSigns', 'drugs', 'nurses'])->where('clinic_id', auth()->user()->parent_id)
            ->where('id', $id)->first();
        $doctors = Clinic::where('app_type', 3)->where('parent_id', auth()->user()->parent_id)->get();
        $nurses = Clinic::where('app_type', 8)->where('parent_id', auth()->user()->parent_id)->get();
        $drugs = Drugs::get();
        return view('nursing.emergency_edit', compact('emergency', 'doctors', 'nurses', 'drugs'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Emergency  $emergency
     * @return \Illuminate\Http\Response
     */
    public function update(EmergencyRequest $request, $id)
    {

        $emergencyData = $request->except([
            'user_id', 'nurse_id',  'enter_date',
            'exit_date', 'type', 'doctor_id', 'nurse_id', 'drugs_id', '_token','_method'
        ]);

        $emergencyData['clinic_id'] = auth()->user()->parent_id;
        $emergencyData['enter_date'] = now();
        $vitalSignData = $request->except([
            'user_id', 'nurse_id', 'notes', 'enter_date',
            'exit_date', 'type', 'doctor_id', 'nurse_id', 'drugs_id', '_token','_method'
        ]);
        $emergency = Emergency::with(['user', 'doctors', 'vitalSigns', 'drugs', 'nurses'])->where('clinic_id', auth()->user()->parent_id)
            ->where('id', $id)->first();
        $emergency->update($emergencyData);
        $vitalSignData['clinic_id'] = auth()->user()->parent_id;
        $vitalSignData['emergency_id'] = $emergency->id;
        $emergency->vitalSigns()->update($vitalSignData);
        $emergency->doctors()->sync($request->input('doctor_id'));
        $emergency->nurses()->sync($request->input('nurse_id'));
        $emergency->drugs()->sync($request->input('drugs_id'));
        return redirect()->route('emergency.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Emergency  $emergency
     * @return \Illuminate\Http\Response
     */
    public function destroy(Emergency $emergency)
    {
        //
    }

    public function newPatient(Request $request)
    {
        $cities = City::where('status', 1)->select('id', 'name_' . $this->lang() . ' as name')->get();
        return view('nursing.add_emergency_patient', compact('cities'));
    }
    public function savePatient(PatientEmergencyRequest $request)
    {
        $patient = $request->all();
        $patient['platform'] = 3;
        $patient['ID_Number'] = Str::random(10);
        $patient['jwt_token'] = Str::random(75);
        $patient['name'] = $request->name . "-" . $request->father_name . "-" . $request->Grandfather_name . "-" . $request->family_name;
        User::create($patient);
        return redirect()->route('create-emergency.create')->with('success', trans('admin.Patient added successfully'));

    }
}
