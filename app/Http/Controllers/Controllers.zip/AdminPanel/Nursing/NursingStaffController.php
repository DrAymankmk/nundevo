<?php

namespace App\Http\Controllers\AdminPanel\Nursing;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Nursing\NursingStaffRequest;
use App\Models\Clinic;
use App\Models\ClinicPointNursing;
use App\Models\PatientService;
use DateTime;
use Illuminate\Http\Request;

class NursingStaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $nurses = Clinic::with('patientService')->where('app_type', 8)->where('parent_id', auth()->user()->parent_id)->where('is_manager', 0)->where('nursing_point_id', '!=', null)->get();
        $all_nurses = Clinic::where('app_type', 8)->where('parent_id', auth()->user()->parent_id)->where('is_manager', 0)->get();
        $points = ClinicPointNursing::where('clinic_id', auth()->user()->parent_id)->where('status', 1)->get();
        return view('nursing.nursing_staff', compact('nurses', 'points', 'all_nurses'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(NursingStaffRequest $request)
    {


        $clinic = Clinic::findOrFail($request->nurse_id);
        $clinic->update([
            'nursing_point_id' => $request->point_id,
            'notes' => $request->notes,
        ]);
        return response()->json([], 200);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $nurse = Clinic::find($id); // Replace 'Nurse' with your actual model name
        $points = ClinicPointNursing::where('clinic_id', auth()->user()->parent_id)->where('status', 1)->get();

        return response()->json([
            'nurse' => $nurse,
            'points' => $points,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(NursingStaffRequest $request)
    {
        $clinic = Clinic::findOrFail($request->nurse_id);
        $clinic->update([
            'nursing_point_id' => $request->point_id,
            'notes' => $request->notes,
        ]);
        return response()->json([], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $clinic = Clinic::findOrFail($id);
        $clinic->update([
            'nursing_point_id' => null,
            'notes' => null,
        ]);
        return response()->json([], 200);
    }

    public function search(Request $request)
    {
        $searchQuery = $request->query('query');

        // Perform the search operation based on the query
        $nurses = Clinic::with('clinicPointNursing')
            ->select('id', 'name', 'phone', 'nursing_point_id')
            ->where(function ($query) use ($searchQuery) {
                $query->where('name', 'like', '%' . $searchQuery . '%')
                    ->orWhere('phone', 'like', '%' . $searchQuery . '%');
            })
            ->where('app_type', 8)
            ->where('parent_id', auth()->user()->parent_id)
            ->where('is_manager', 0)
            ->where('nursing_point_id', '!=', null)
            ->get();


        // Transform and localize the point name based on the language
        $nurses->transform(function ($nurse) {
            $pointName = $nurse->clinicPointNursing ? app()->getLocale() == 'en' ? $nurse->clinicPointNursing->name_en : $nurse->clinicPointNursing->name_ar : '';
            $nurse->setAttribute('point_name', $pointName);
            return $nurse;
        });

        // Return the search results as a JSON response
        return response()->json(['nurses' => $nurses]);
    }
    public function filter(Request $request)
    {
        $fromDate = DateTime::createFromFormat('d/m/Y', $request->fromDate);
        $toDate = DateTime::createFromFormat('d/m/Y', $request->toDate);
        // Format the dates as 'Y-m-d' (e.g., 2023-12-04)
        $formattedFromDate = $fromDate->format('Y-m-d');
        $formattedToDate = $toDate->format('Y-m-d');
        $nurses = Clinic::with('patientService')
            ->where('app_type', 8)
            ->where('parent_id', auth()->user()->parent_id)
            ->where('is_manager', 0)
            ->where('nursing_point_id', '!=', null)
            ->whereHas('patientService', function ($query) use ($formattedFromDate, $formattedToDate) {
                $query->whereBetween('created_at', [$formattedFromDate, $formattedToDate]);
            })
            ->get();
        $nurses->transform(function ($nurse) {
            $pointName = $nurse->clinicPointNursing ? app()->getLocale() == 'en' ? $nurse->clinicPointNursing->name_en : $nurse->clinicPointNursing->name_ar : '';
            $nurse->setAttribute('point_name', $pointName);
            return $nurse;
        });

        return response()->json(['nurses' => $nurses]);
    }

    public function nursingServices(Request $request)
    {
        $nurseServises = PatientService::with(['services', 'user', 'doctor'])->where('nurse_id', $request->id)->get();
        $nurse_id = $request->id;
        return view('nursing.nurse_services', compact('nurseServises', 'nurse_id'));
    }
    public function nursingServicesfilter(Request $request)
    {
        $fromDate = DateTime::createFromFormat('d/m/Y', $request->fromDate);
        $toDate = DateTime::createFromFormat('d/m/Y', $request->toDate);


        // Format the dates as 'Y-m-d' (e.g., 2023-12-04)
        $formattedFromDate = $fromDate->format('Y-m-d');
        $formattedToDate = $toDate->format('Y-m-d');
        $nurseServises = PatientService::with(['services', 'user', 'doctor'])
            ->where('nurse_id', $request->id)
            ->whereBetween('created_at', [$formattedFromDate,  $formattedToDate])
            ->get();

        return response()->json(['nurseServises' => $nurseServises]);
    }
}
