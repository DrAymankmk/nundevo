<?php

namespace App\Http\Controllers\AdminPanel\Lab;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Doctors\CreateUpdateDrugSectionRequest;
use App\Http\Requests\Admin\Lab\CreateUpdateCategoryAnalysisRequest;
use App\Models\ClinicServices;
use App\Models\Service;
use App\Models\ServicesCategory;
use Illuminate\Http\Request;

class CategoryAnalysisController extends Controller
{
    // show category_analysis
    function index($category_id)
    {
        if (auth()->user()->app_type == 25) {
            $relation = 'analysis';
        } else {
            $relation = 'rays';
        }
        $service = ServicesCategory::where('id', $category_id)->select('id', 'name_ar', 'name_en', 'status', 'name_' . $this->lang() . ' as title')->first();
        return view('labs.categories.services', compact('service', 'relation'));
    }

    // create category_analysis
    function create_category_analysis($category_id)
    {
        $service = ServicesCategory::where('id', $category_id)->select('id', 'name_ar', 'name_en', 'status', 'name_' . $this->lang() . ' as title')->first();
        return view('labs.categories.add_services', compact('service'));
    }

    // create category_analysis
    function update_category_analysis($id)
    {
        $service = Service::with('clinic_service')->where('id', $id)->select('id', 'name_ar', 'name_en', 'status', 'name_' . $this->lang() . ' as title','price','notes','status','category_id','abbrev')->first();
        $clinic_service = ClinicServices::where(['clinic_id'=>auth()->user()->parent_id,'service_id'=>$service->id])->first();
        return view('labs.categories.edit_services', compact('service','clinic_service'));
    }

    // add category_analysis
    public function add_category_analysis($category_id, CreateUpdateCategoryAnalysisRequest $request)
    {
        $data = $request->all();
        $data['category_id'] = $category_id;
        $data['type'] = auth()->user()->app_type == 25 ? 1 : 2;
        $add_service = Service::create($data);
        if ($add_service) {
            $clinic_service = $request->all();
            $clinic_service['clinic_id'] = auth()->user()->parent_id;
            $clinic_service['service_id'] = $add_service->id;
            $clinic_service['created_by'] = auth()->user()->id;
            $clinic_service['type'] = auth()->user()->app_type == 25 ? 1 : 2;
            $add_clinic_service = ClinicServices::create($clinic_service);
            session()->flash('success', trans('messages.Added'));
            return redirect()->route('category-analysis', $category_id);
        }
    }

    //Edit category_analysis
    public function edit_category_analysis($id, CreateUpdateCategoryAnalysisRequest $request)
    {
        $edit_section = Service::where('id', $id)->first();
        $data = $request->all();
        $edit_section->update($data);
        if ($edit_section) {
            $clinic_service = $request->all();
            $clinic_service['clinic_id'] = auth()->user()->parent_id;
            $clinic_service['service_id'] = $edit_section->id;
            $clinic_service['created_by'] = auth()->user()->id;
            $clinic_service['type'] = auth()->user()->app_type == 25 ? 1 : 2;
            ClinicServices::updateOrCreate(
                [
                    'clinic_id' => auth()->user()->parent_id,
                    'service_id' => $edit_section->id,
                ],
                $clinic_service
            );
        }
        session()->flash('success', trans('messages.updated'));
        return redirect()->route('category-analysis', $edit_section->category_id);
    }

    public function update_status_category_analysis($id, $status)
    {
        $status_section = Service::where('id', $id)->first();
        $status_section->status = $status;
        $status_section->save();
        session()->flash('success', trans('admin.update_status'));
    }

    // delete category_analysis
    function destroy_category_analysis($id)
    {
        Service::where('id', $id)->delete();
        session()->flash('success', trans('messages.deleted'));
        return redirect()->back();
    }
}
