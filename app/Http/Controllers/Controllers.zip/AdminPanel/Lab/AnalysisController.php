<?php

namespace App\Http\Controllers\AdminPanel\Lab;

use App\Http\Controllers\Controller;
use App\Models\PatientService;
use App\Models\Reservations;
use App\Models\ResultManual;
use App\Models\Service;
use App\Models\User;
use Illuminate\Http\Request;

class AnalysisController extends Controller
{
    function patient_analysis($patient_id)
    {
        $lang = app()->getLocale() ?? 'en';
        $user = User::where('id', $patient_id)->first();
        if (auth()->user()->app_type == 25) {
            $type = 1;
        } else {
            $type = 2;
        }
        $data['patient_services'] = PatientService::with('services')->where(['user_id' => $patient_id, 'type' => $type])->orderBy('id', 'desc')->get();
        return view('labs.analysis.index', compact('lang', 'user', 'data'));
    }

    function confirm_receipt(Request $request, $analysis_id)
    {
        $ID_Number = $request->ID_Number;
        if ($ID_Number != auth()->user()->ID_Number) {
            session()->flash('failed', trans('admin.lab.check_ID_Number'));
            return redirect()->back();
        }
        $update_analysis = PatientService::whereId($analysis_id)->first();
        $update_analysis->status = 1;
        $update_analysis->save();
        session()->flash('success', trans('admin.lab.confirm_receipt_success'));
        return redirect()->back();
    }


    function upload_result($test_result_id)
    {
        $lang = app()->getLocale() ?? 'en';
        $test_result = PatientService::with('result_manual')->whereId($test_result_id)->first();
        $data['title'] = trans('admin.lab.Attach_result');
        return view('labs.analysis.result', compact('test_result', 'data'));
    }

    function send_result_analysis(Request $request, $test_result_id)
    {
        $data = $request->all();
        $update_analysis = PatientService::whereId($test_result_id)->first();
        $update_analysis->update($data);
        if ($update_analysis) {
            $added = ResultManual::updateOrCreate(
                [
                    'patient_service_id' => $update_analysis->id,
                ],
                $data
            );
        }
        session()->flash('success', trans('admin.added'));
        return redirect()->back();
    }


    function re_analysis(Request $request, $analysis_id)
    {
        $data = $request->all();
        $analysis = PatientService::where('id', $analysis_id)->first();
        $data['user_id'] = $analysis->user_id;
        $data['reservation_id'] = $analysis->reservation_id;
        $data['doctor_id'] = $analysis->doctor_id;
        $data['service_id'] = $analysis->service_id;
        $data['type'] = $analysis->type;
        $data['price'] = $analysis->price;
        $data['discount'] = $analysis->discount ?? null;
        $add_services = PatientService::create($data);
        if ($add_services) {
            session()->flash('success', trans('messages.Added'));
            return redirect()->back();
        }
    }
}
