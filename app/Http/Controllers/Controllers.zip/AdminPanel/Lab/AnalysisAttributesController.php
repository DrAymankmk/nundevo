<?php

namespace App\Http\Controllers\AdminPanel\Lab;

use App\Http\Controllers\Controller;
use App\Models\AgeCategories;
use App\Models\Service;
use App\Models\ServiceAnalysisAttributes;
use App\Models\ServicesCategory;
use Illuminate\Http\Request;

class AnalysisAttributesController extends Controller
{
    // analysis attributes
    function index($service_id)
    {
        $age_categories = AgeCategories::where('status',1)->get();
        $service = Service::whereId($service_id)->select('id', 'name_ar', 'name_en','name_'.app()->getLocale().' as name', 'status', 'name_' . $this->lang() . ' as title')->first();
        return view('labs.analysis.attributes', compact('service','age_categories'));
    }

    public function create_analysis_attributes ($service_id, Request $request)
    {
        $data = $request->all();
        $type = $request->type;
// Create the main category
        if ($type == 1) {
            $i = 0;
            foreach ($request->category_id as $key=>$category) {

                $add_service = ServiceAnalysisAttributes::updateOrCreate(
                    [
                        'id' => $category ?? null,
                    ],
                    [
                        'service_id' => $service_id,
                        'age_id' => $request->age_id[$key],
                        'name' => $request->category_name[$key],
                    ]
                );
                $i++;

                if ($add_service) {
                    $x = 0;
                    foreach ($request->parent_id as $index => $test_name) {
                        // Check if the index exists in other arrays to avoid "Undefined offset" errors
                        if (isset($request->name[$x])) {
                            ServiceAnalysisAttributes::updateOrCreate(
                                [
                                    'id' => $test_name,
                                ],
                                [
//                                    'parent_id' =>  $add_service->id, // Set parent_id to the current category's id
                                    'service_id' => $service_id,
                                    'age_id' => $request->age_id[$key],
                                    'unit' => $request->unit[$x], // Use $index for array indexing
                                    'name' => $request->name[$x], // Use $index for array indexing
                                    'normal_value' => $request->normal_value[$x], // Use $index for array indexing
                                    'normal_value_female' => $request->normal_value_female[$x], // Use $index for array indexing
                                ]
                            );
                            $x++;
                        }
                    }
                }

            }
        } else {

                $add_service = ServiceAnalysisAttributes::updateOrCreate(
                    [
                        'service_id' => $service_id,
                        'age_id' => $request->age_id,
                        'name' => $request->category_name,
                    ],
                    [
                        'service_id' => $service_id,
                        'age_id' => $request->age_id,
                        'name' => $request->category_name,
                    ]
                );
                if ($add_service) {
                    $x = 0;
                    foreach ($request->name as $index => $test_name) {
                        // Check if the index exists in other arrays to avoid "Undefined offset" errors
                        if (isset($request->name[$x])) {
//                        if (isset($request->name[$x], $request->unit[$x], $request->normal_value[$x])) {

                            ServiceAnalysisAttributes::updateOrCreate(
                                [
                                    'service_id' => $service_id,
                                    'parent_id' => $add_service->id,
                                    'name' => $test_name,
                                    'age_id' => $request->age_id,
                                ],
                                [
                                    'name' => $test_name,
                                    'parent_id' =>  $add_service->id, // Set parent_id to the current category's id
                                    'service_id' => $service_id,
                                    'age_id' => $request->age_id,
                                    'unit' => $request->unit[$x], // Use $index for array indexing
                                    'normal_value' => $request->normal_value[$x], // Use $index for array indexing
                                    'normal_value_female' => $request->normal_value_female[$x], // Use $index for array indexing
                                ]
                            );
                            $x++;
                        }
                    }
                }

        }

        session()->flash('success', trans('messages.Added'));
        return redirect()->back();
// or return redirect()->route('category-analysis', $service_id); // Uncomment this line if you want to redirect to a specific route after processing all categories
    }
}
