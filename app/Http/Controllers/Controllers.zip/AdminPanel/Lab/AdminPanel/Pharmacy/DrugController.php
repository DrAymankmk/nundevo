<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\DrugRequest;
use App\Models\Drugs;
use App\Models\DrugSection;
use App\Models\Inventory;
use App\Models\ItemUnit;
use App\Models\PharmacyInvoiceItem;
use App\Models\PurchaseInvoiceItem;
use App\Models\Supplier;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DrugController extends Controller
{
    public function index()
    {
        $data['drugs'] = Drugs::query()
            ->select(
                'drugs.id',
                'drugs.name_en as drug_name_en',
                'drugs.name_ar as drug_name_ar',
                'drugs.scientific_name_ar as scientific_name_ar',
                'drugs.scientific_name_en as scientific_name_en',
                'drugs.international_barcode as international_barcode',
                'sections.name_ar as section_name_ar',
                'sections.name_en as section_name_en',
                'drug_sections.content_of_grand_unit',
                'drug_sections.price_of_grand_unit',
                DB::raw('COALESCE(SUM(CASE WHEN pharmacy_invoices.movement_type = "purchases" THEN pharmacy_invoice_items.quantity ELSE 0 END), 0) as drugs_quantity')
            )
            ->leftJoin('drugs as sections', 'drugs.parent_id', '=', 'sections.id')
            ->leftJoin('drug_sections', 'drug_sections.drug_id', '=', 'drugs.id')
            ->leftJoin('pharmacy_invoice_items', 'pharmacy_invoice_items.drug_id', '=', 'drugs.id')
            ->leftJoin('pharmacy_invoices', 'pharmacy_invoices.id', '=', 'pharmacy_invoice_items.pharmacy_invoice_id')
            ->whereNotNull('drugs.parent_id')
            ->groupBy('drugs.id')
            ->orderBy('drugs.id', 'DESC')
            ->get()
        ;


        $data['medicineDepartments'] = Drugs::query()->whereNull('parent_id')->get();
        $data['itemUnits']           = ItemUnit::query()->select('id', 'name')->get();
        $data['suppliers']           = Supplier::query()->select('id', 'name')->get();



        return view('pharmacy.drugs.index', $data);

    }

    public function getDrugsByDrugId($drugId)
    {
        $drugs = Drugs::query()
            ->select(
                'drugs.id',
                'drugs.name_en as drug_name_en',
                'drugs.name_ar as drug_name_ar',
                'drugs.international_barcode as international_barcode',
                'sections.name_ar as section_name_ar',
                'sections.name_en as section_name_en',
                'drug_sections.content_of_grand_unit',
                'drug_sections.price_of_grand_unit',
            )
            ->leftJoin('drugs as sections','drugs.parent_id','=','sections.id')
            ->leftJoin('drug_sections','drug_sections.drug_id','=','drugs.id')
            ->whereNotNull('drugs.parent_id')
            ->where('drugs.parent_id',$drugId)
            ->orderBy('drugs.id', 'DESC')
            ->groupBy('drugs.id')
            ->get();
        return view('pharmacy.drugs.index', compact('drugs'));
    }

    public function store(DrugRequest $request)
    {
        $expirationDate = $request->expiration_date ? Carbon::createFromFormat('Y-m-d', $request->expiration_date)->format('Y-m-d') : null;

        try{
            DB::beginTransaction(); // Start transaction

            $drug = Drugs::query()->create([
                'name_ar'               => $request->trade_name_ar,
                'name_en'               => $request->trade_name_en,
                'scientific_name_ar'    => $request->scientific_name_ar,
                'scientific_name_en'    => $request->scientific_name_en,
                'short_code'            => $request->short_code,
                'alternative_id'        => $request->alternative_id,
                'parent_id'             => $request->group_id,
                'type'                  => auth()->user()->app_type == 5 ? 'pharmacy' : 'admin',
                'expiration_date'       => $expirationDate,
                'concentration'         => $request->concentration,
                'usage_or_form'         => $request->usage_or_form,
                'note'                  => $request->note,
                'international_barcode' => $request->international_barcode,
                'clinic_id'             => auth()->user()->parent_id,
                'pharmacy_id'           => auth()->user()->id,

            ]);

            if (auth()->user()->app_type == 5) {
                DrugSection::query()->create([
                    'clinic_id'             => auth()->user()->parent_id,
                    'pharmacy_id'           => auth()->user()->id,
                    'drug_id'               => $drug->id,
                    'grand_unit_id'         => $request->grand_unit_id,
                    'micro_unit_id'         => $request->micro_unit_id,
                    'content_of_grand_unit' => $request->content_of_grand_unit,
                    'price_of_grand_unit'   => $request->price_of_grand_unit,
                    'discount'              => $request->discount,
                    'supplier_id'           => $request->supplier_id,
                    'returns'               => $request->returns,
                    'limit_of_deficiencies' => $request->limit_of_deficiencies,
                    'recession_limit'       => $request->recession_limit,
                ]);
            }

            DB::commit(); // Commit transaction

            session()->flash('success', trans('pharmacy.created'));
            return redirect()->back();

        } catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs

            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }
    }

    public function edit($drugId)
    {

        $data['drug'] = Drugs::query()->findOrFail($drugId);
        if(!isset($data['drug'])){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }


        $data['medicineDepartments'] = Drugs::query()->whereNull('parent_id')->get();
        $data['itemUnits']           = ItemUnit::query()->select('id', 'name')->get();
        $data['suppliers']           = Supplier::query()->select('id', 'name')->get();


        return response([
            'view' => view('pharmacy.drugs.edit', $data)->render(),
        ]);
    }

    public function update(Request $request, $drugId)
    {
        try{
            DB::beginTransaction(); // Start transaction

            $drug = Drugs::query()->findOrFail($drugId);
            if (!isset($drug)) {
                session()->flash('not_fount', trans('pharmacy.not_found'));
                return redirect()->back();
            }

            // Check if expiration_date exists and is not empty
            if (!empty($request->expiration_date)) {
                $expirationDate = Carbon::createFromFormat('m-d-Y', $request->expiration_date)->format('Y-m-d');
            } else {
                $expirationDate = null; // Handle the case where the date might be empty
            }
            $drug->update([
                'name_ar'               => $request->trade_name_ar,
                'name_en'               => $request->trade_name_en,
                'scientific_name_ar'    => $request->scientific_name_ar,
                'scientific_name_en'    => $request->scientific_name_en,
                'short_code'            => $request->short_code,
                'parent_id'             => $request->group_id,
                'type'                  => auth()->user()->app_type == 5 ? 'pharmacy' : 'admin',
                'expiration_date'       => $expirationDate,
                'concentration'         => $request->concentration,
                'usage_or_form'         => $request->usage_or_form,
                'note'                  => $request->note,
                'international_barcode' => $request->international_barcode,
                'clinic_id'             => auth()->user()->parent_id,
                'pharmacy_id'           => auth()->user()->id,

            ]);

            if (auth()->user()->app_type == 5) {

                DrugSection::query()->updateOrCreate(['id' => $request->drug_section_id],[
                    'clinic_id'             => auth()->user()->parent_id,
                    'pharmacy_id'           => auth()->user()->id,
                    'drug_id'               => $drug->id,
                    'grand_unit_id'         => $request->grand_unit_id,
                    'micro_unit_id'         => $request->micro_unit_id,
                    'content_of_grand_unit' => $request->content_of_grand_unit,
                    'price_of_grand_unit'   => $request->price_of_grand_unit,
                    'discount'              => $request->discount,
                    'supplier_id'           => $request->supplier_id,
                    'returns'               => $request->returns,
                    'limit_of_deficiencies' => $request->limit_of_deficiencies,
                    'recession_limit'       => $request->recession_limit,
                ]);
            }

            DB::commit(); // Commit transaction

            session()->flash('success', trans('pharmacy.updated'));
            return redirect()->back();

        } catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs

            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }
    }

    public function delete($drugId)
    {
        $drug = Drugs::query()->findOrFail($drugId);
        if (!isset($drug)) {
            session()->flash('not_fount', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        if($drug->drugSection){
            $drug->drugSection->delete();

        }


        if($drug->type != 'admin'){
            $drug->delete();
        }

        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $searchQuery = $request->query('query');


        $drugs = Drugs::query()
            ->select(
                'drugs.id',
                'drugs.name_en as drug_name_en',
                'drugs.name_ar as drug_name_ar',
                'drugs.scientific_name_ar as scientific_name_ar',
                'drugs.scientific_name_en as scientific_name_en',
                'drugs.international_barcode as international_barcode',
                'sections.name_ar as section_name_ar',
                'sections.name_en as section_name_en',
                'drug_sections.content_of_grand_unit',
                'drug_sections.price_of_grand_unit',
                DB::raw('COALESCE(SUM(CASE WHEN pharmacy_invoices.movement_type = "purchases" THEN pharmacy_invoice_items.quantity ELSE 0 END), 0) as drugs_quantity')

            )
            ->leftJoin('drugs as sections', 'drugs.parent_id', '=', 'sections.id')
            ->leftJoin('drug_sections', 'drug_sections.drug_id', '=', 'drugs.id')
            ->leftJoin('pharmacy_invoice_items', 'pharmacy_invoice_items.drug_id', '=', 'drugs.id')
            ->leftJoin('pharmacy_invoices', 'pharmacy_invoices.id', '=', 'pharmacy_invoice_items.pharmacy_invoice_id')
            ->whereNotNull('drugs.parent_id')
            ->where(function ($query) use ($searchQuery) {
                if (!empty($searchQuery)) {
                    $query->where(function ($que) use ($searchQuery) {
                        $que->where('drugs.name_ar', 'like', '%' . $searchQuery . '%')
                            ->orWhere('drugs.name_en', 'like', '%' . $searchQuery . '%')
                            ->orWhere('drugs.scientific_name_ar', 'like', '%' . $searchQuery . '%')
                            ->orWhere('drugs.scientific_name_en', 'like', '%' . $searchQuery . '%')
                            ->orWhere('sections.name_en', 'like', '%' . $searchQuery . '%')
                            ->orWhere('sections.name_ar', 'like', '%' . $searchQuery . '%')
                            ->orWhere('drug_sections.content_of_grand_unit', 'like', '%' . $searchQuery . '%')
                            ->orWhere('drug_sections.price_of_grand_unit', 'like', '%' . $searchQuery . '%');
                    });
                }
            })
            ->get();

        if($request->is_alternative != 1){
            return view('pharmacy.drugs.search', compact('drugs'));
        }else{
            return view('pharmacy.drugs.alternative_search', compact('drugs'));

        }
    }

    public function getBalancesOfDrug($drugId)
    {
        $pharmacyId = auth()->user()->id;


        $stores = PharmacyInvoiceItem::query()
            ->select(
                'stores.name as store_name',
                'pharmacy_invoice_items.drug_id as drug_id',
                'drugs.name_en as drug_name_en',
                'drugs.name_ar as drug_name_ar',
                'item_units.name as item_unit_name',
                'pharmacy_invoice_items.price as price',
                DB::raw('SUM(pharmacy_invoice_items.quantity) as quantity'),
                DB::raw('COALESCE(
                    CASE
                        WHEN pharmacy_invoice_items.quantity != 0
                        THEN pharmacy_invoice_items.price * pharmacy_invoice_items.quantity
                        ELSE 0
                    END,
                    0
                ) as total_amount')
            )
            ->leftJoin('pharmacy_invoices', 'pharmacy_invoices.id', '=', 'pharmacy_invoice_items.pharmacy_invoice_id')
            ->leftJoin('stores', 'stores.id', '=', 'pharmacy_invoices.store_id')
            ->leftJoin('drugs', 'drugs.id', '=', 'pharmacy_invoice_items.drug_id')
            ->leftJoin('drug_sections', 'drug_sections.drug_id', '=', 'drugs.id')
            ->leftJoin('item_units', 'item_units.id', '=', 'drug_sections.grand_unit_id')
            ->where('pharmacy_invoices.movement_type', '=','purchases')
            ->where('pharmacy_invoices.pharmacy_id', '=', $pharmacyId)
            ->where('pharmacy_invoice_items.drug_id', '=', $drugId)
            ->where('pharmacy_invoice_items.drug_id', '=', $drugId)
            ->groupBy('stores.id', 'pharmacy_invoice_items.drug_id')
            ->get();


        return response([
            'view' => view('pharmacy.drugs.balance', compact('stores'))->render(),
        ]);
    }

    public function getAlternativesDrugs($drugId)
    {

        // this to get name  of drug and group id
        $data['medicationAlternative'] = Drugs::query()
            ->select('id','name_ar','name_en','parent_id')
            ->where('id','=',$drugId)
            ->first();


        $parentId = $data['medicationAlternative']->parent_id;



        $alternativeIds = Drugs::query()
            ->where('alternative_id','=',$drugId)
            ->where('parent_id','=', $parentId)
            ->get()
            ->pluck('id')
            ->toArray();




        $data['alternativeDrugs'] = Drugs::query()
            ->select('id','name_ar','name_en','parent_id')
            ->whereNotIn('id',$alternativeIds)
            ->where('parent_id','=', $parentId)
            ->where('id','<>', $drugId)
            ->get();


        $data['drugs'] = Drugs::query()
            ->select(
                'drugs.id',
                'drugs.name_en as drug_name_en',
                'drugs.name_ar as drug_name_ar',
                'drugs.scientific_name_ar as scientific_name_ar',
                'drugs.scientific_name_en as scientific_name_en',
                'drugs.international_barcode as international_barcode',
                'drug_sections.price_of_grand_unit',
            )
            ->leftJoin('drugs as sections','drugs.parent_id','=','sections.id')
            ->leftJoin('drug_sections','drug_sections.drug_id','=','drugs.id')
            ->where('drugs.parent_id','=', $parentId)
            ->where('drugs.alternative_id', '=', $drugId)
            ->orderBy('drugs.id', 'DESC')
            ->groupBy('drugs.id')
            ->get();
        return view('pharmacy.drugs.alternatives', $data);

    }


    public function updateAlternativeDrug(Request  $request)
    {
//        return $request->all();
        $drug = Drugs::query()->find($request->drug_id);

        if (!isset($drug)) {
            session()->flash('not_fount', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $drug->update([
            'alternative_id' => $request->alternative_id
        ]);

        session()->flash('success', trans('pharmacy.updated'));
        return redirect()->back();
    }

    public function deleteAlternativeDrug($drugId)
    {
        $drug = Drugs::query()->findOrFail($drugId);
        if (!isset($drug)) {
            session()->flash('not_fount', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $drug->update([
            'alternative_id' => null
        ]);


        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();

    }


}
