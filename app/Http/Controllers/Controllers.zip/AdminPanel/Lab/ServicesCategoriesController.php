<?php

namespace App\Http\Controllers\AdminPanel\Lab;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\AddDepartment;
use App\Models\Drugs;
use App\Models\ServicesCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ServicesCategoriesController extends Controller
{
    // show services_category
    function index(Request $request)
    {
        $check_authorization = Auth::user()->parent_id;
        if (auth()->user()->app_type == 25) {
            $type = 1;
        } else {
            $type = 2;
        }
//        $data['categories'] = ServicesCategory::where('type', $type)->orderBy('id', 'desc')->paginate(10);
        $query = ServicesCategory::where(function ($q) use ($check_authorization, $type) {
            $q->where('type', $type);
            $q->orwhere('clinic_id', $check_authorization);
            $q->orwhereIn('flag', [1, 2]);
        })->orderBy('id', 'desc');

        if ($request->name) {
            $query->where(function ($q) use ($request) {
                $q->where('name_ar', 'like', '%' . $request->name . '%')
                    ->orWhere('name_en', 'like', '%' . $request->name . '%');
            });
        }

        $data['categories'] = $query->paginate(20);
        return view('labs.categories.index', compact('data'));
    }

    // create services_category
    function create_services_category()
    {
        return view('labs.categories.add_category');
    }

    // create services_category
    function update_services_category($id)
    {
        $category = ServicesCategory::where('id', $id)->select('id', 'name_ar', 'name_en', 'status', 'name_' . $this->lang() . ' as title')->first();
        return view('labs.categories.edit_category', compact('category'));
    }

    // add services_category
    public function add_services_category(Request $request)
    {
        $data = $request->all();
        if (auth()->user()->app_type == 25) {
            $data['type'] = 1;
        } else {
            $data['type'] = 2;
        }
        if (auth()->user()->app_type == 25 || auth()->user()->app_type == 26) {
            $flag = 2;
        } else {
            $flag = 1;
        }
        $data['flag'] = $flag;
        $data['clinic_id'] = auth()->user()->id;
        $add_service_category = ServicesCategory::create($data);
        if ($add_service_category) {
            session()->flash('success', trans('messages.Added'));
            return redirect()->route('services-categories');
        }
    }

    //Edit services_category
    public function edit_services_category($id, AddDepartment $request)
    {
        $edit_drug = ServicesCategory::where('id', $id)->first();
        $data = $request->all();
        $edit_drug->update($data);
        session()->flash('success', trans('messages.updated'));
        return redirect()->route('services-categories');
    }

    public function update_status_services_category($id, $status)
    {
        $status_drug = ServicesCategory::where('id', $id)->first();
        $status_drug->status = $status;
        $status_drug->save();
        session()->flash('success', trans('admin.change_status'));
    }


    // delete services_category
    function destroy_services_category($id)
    {
        $Drug = ServicesCategory::where('id', $id)->first();
        $Drug->delete();
        session()->flash('success', trans('messages.deleted'));
        return redirect()->back();
    }
}
