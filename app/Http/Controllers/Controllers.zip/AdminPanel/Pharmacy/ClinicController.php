<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\ClinicRequest;
use App\Models\Clinic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ClinicController extends Controller
{


    public function index(Request $request )
    {
        $clinicId = auth()->user()->id;
        $clinic   = Clinic::query()->find($clinicId);
        return view('pharmacy.pharmacies.index', compact('clinic'));
    }

    public function update($clinicId,ClinicRequest $request)
    {
        $clinic = Clinic::query()->find($clinicId);

        $clinic->name             = $request->name;
        $clinic->phone            = $request->phone;
        $clinic->address          = $request->address;
        $clinic->post_number      = $request->post_number;
        $clinic->fax              = $request->fax ;
        $clinic->email            = $request->email;
        $clinic->website          = $request->website;
        $clinic->monitor_username = $request->monitor_username;
        $clinic->monitor_password = Hash::make($request->monitor_password);
        $clinic->save();


        session()->flash('success', trans('pharmacy.updated'));
        return redirect()->back();

    }
}
