<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\PurchaseInvoiceRequest;
use App\Models\Drugs;
use App\Models\PharmacyInvoice;
use App\Models\PharmacyInvoiceItem;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseInvoiceItem;
use App\Models\Store;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class PurchaseInvoiceController extends Controller
{
    public function index()
    {
        $purchaseInvoices = PharmacyInvoice::query()
            ->select(
                'pharmacy_invoices.id',
                'pharmacy_invoices.is_saved_invoice',
                'pharmacy_invoices.invoice_number',
                'pharmacy_invoices.movement_type',
                'pharmacy_invoices.payment_method',
                'pharmacy_invoices.paid_value',
                'pharmacy_invoices.total_amount',
                'stores.name as store_name',
                'suppliers.name as supplier_name',
                'pharmacy_invoices.count_items_in_invoice as items_count',
                DB::raw("DATE_FORMAT(pharmacy_invoices.date, '%Y-%m-%d') as date"),

            )
            ->leftJoin('stores', 'stores.id', '=', 'pharmacy_invoices.store_id')
            ->leftJoin('suppliers', 'suppliers.id', '=', 'pharmacy_invoices.supplier_id')
            ->where('pharmacy_invoices.invoice_type','=','purchases')
            ->orderBy('pharmacy_invoices.id','DESC')
            ->groupBy('pharmacy_invoices.id')
            ->get();

        return view('pharmacy.purchase_invoices.index', compact('purchaseInvoices'));
    }

    public function create()
    {
        $clinicId          = auth()->user()->parent_id;
        $data['suppliers'] = Supplier::query()->select('id', 'name')
                                     ->where('clinic_id', '=', $clinicId)->get();

        $data['stores']    = Store::query()->select('id', 'name')
                                  ->where('clinic_id', '=', $clinicId)->get();

        $data['drugs']     = Drugs::query()
                                  ->select('id', 'name_ar', 'name_en', 'parent_id')
                                  ->whereNotNull('parent_id')->get();

        return view('pharmacy.purchase_invoices.create', $data);

    }

    public function store(PurchaseInvoiceRequest $request)
    {
        try {
            DB::beginTransaction(); // Start transaction

            $purchaseInvoice = PharmacyInvoice::storeInvoice($request);

            $discount              = [];
            $netTotal              = [];
            $netTotalAfterDiscount = [];
            $taxValue              = [];
            $totalAmount           = [];

            if($request->drug_id){
                foreach ($request->drug_id as $index => $drugId){

                    $bonus              = floatval($request->bonus[$index]);
                    $percentageDiscount = floatval($request->percentage_discount[$index]);
                    $valueDiscount      = floatval($request->value_discount[$index]);
                    $fixedDiscount      = floatval($request->fixed_discount[$index]);
                    $price              = floatval($request->price[$index]);
                    $quantity           = floatval($request->quantity[$index]);

                    $netTotal[$index] = $price * $quantity;
                    $discount[$index] = $bonus + ($netTotal[$index] * $percentageDiscount / 100) + $valueDiscount + $fixedDiscount;

                    $netTotalAfterDiscount[$index] = $netTotal[$index] - $discount[$index];
                    $taxValue[$index]              = ($netTotal[$index] - $discount[$index]) * floatval($request->tax[$index]) / 100;
                    $totalAmount[$index]           = ($netTotal[$index] - $discount[$index]) + $taxValue[$index];

                    PharmacyInvoiceItem::storeInvoiceItem($request, $purchaseInvoice->id, $index, $netTotal[$index], $netTotalAfterDiscount[$index], $taxValue[$index], $totalAmount[$index]);
                }

                $purchaseInvoice->net_total                = array_sum($netTotal);
                $purchaseInvoice->net_total_after_discount = array_sum($netTotalAfterDiscount);
                $purchaseInvoice->tax_value                = array_sum($taxValue);
                $purchaseInvoice->total_amount             = array_sum($totalAmount);

                $purchaseInvoice->save();
            }
            DB::commit(); // Commit transaction
            session()->flash('success', trans('pharmacy.created'));
            return redirect()->route('pharmacy.purchase-invoice.index');


        }catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }





    }

    public function edit($pharmacyInvoiceId)
    {
         $data['purchaseInvoice'] = PharmacyInvoice::query()->findOrFail($pharmacyInvoiceId);
        if(!isset($data['purchaseInvoice'])){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }


        $clinicId          = auth()->user()->parent_id;
        $data['suppliers'] = Supplier::query()->select('id', 'name')
                                     ->where('clinic_id', '=', $clinicId)->get();

        $data['stores']    = Store::query()->select('id', 'name')
                                  ->where('clinic_id', '=', $clinicId)->get();

        $data['drugs']     = Drugs::query()
                                  ->select('id', 'name_ar', 'name_en', 'parent_id')
                                  ->whereNotNull('parent_id')->get();

        return view('pharmacy.purchase_invoices.edit',$data);

    }

    public function update(PurchaseInvoiceRequest $request, $pharmacyInvoiceId)
    {
        try {
            $pharmacyInvoice = PharmacyInvoice::query()->findOrFail($pharmacyInvoiceId);

            if(!isset($pharmacyInvoice)){
                session()->flash('error', trans('pharmacy.not_found'));
                return redirect()->back();
            }

            DB::beginTransaction(); // Start transaction


            PharmacyInvoice::updateInvoice($request);


            $discount              = [];
            $netTotal              = [];
            $netTotalAfterDiscount = [];
            $taxValue              = [];
            $totalAmount           = [];

            if($request->drug_id){
                foreach ($request->drug_id as $index => $drugId){

                    $bonus              = floatval($request->bonus[$index]);
                    $percentageDiscount = floatval($request->percentage_discount[$index]);
                    $valueDiscount      = floatval($request->value_discount[$index]);
                    $fixedDiscount      = floatval($request->fixed_discount[$index]);
                    $price              = floatval($request->price[$index]);
                    $quantity           = floatval($request->quantity[$index]);

                    $netTotal[$index] = $price * $quantity;
                    $discount[$index] = $bonus + ($netTotal[$index] * $percentageDiscount / 100) + $valueDiscount + $fixedDiscount;

                    $netTotalAfterDiscount[$index] = $netTotal[$index] - $discount[$index];
                    $taxValue[$index]              = ($netTotal[$index] - $discount[$index]) * floatval($request->tax[$index]) / 100;
                    $totalAmount[$index]           = ($netTotal[$index] - $discount[$index]) + $taxValue[$index];

                    if($request->quantity[$index] != ''){
                        PharmacyInvoiceItem::updateInvoiceItem($request, $pharmacyInvoiceId, $index, $netTotal[$index], $netTotalAfterDiscount[$index], $taxValue[$index], $totalAmount[$index]);
                    }
                }

                $pharmacyInvoice->net_total                = array_sum($netTotal);
                $pharmacyInvoice->net_total_after_discount = array_sum($netTotalAfterDiscount);
                $pharmacyInvoice->tax_value                = array_sum($taxValue);
                $pharmacyInvoice->total_amount             = array_sum($totalAmount);

                $pharmacyInvoice->save();
            }
            DB::commit(); // Commit transaction
            session()->flash('success', trans('pharmacy.created'));
            return redirect()->route('pharmacy.purchase-invoice.index');

        }catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }





    }

    public function delete($pharmacyInvoiceId)
    {
        $pharmacyInvoice = PharmacyInvoice::query()->findOrFail($pharmacyInvoiceId);

        if(!isset($pharmacyInvoice)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $pharmacyInvoice->delete();
        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $clinicId = auth()->user()->parent_id;

        $searchQuery = $request->query('query');


        $purchaseInvoices = PharmacyInvoice::query()
            ->select(
                'pharmacy_invoices.id',
                'pharmacy_invoices.is_saved_invoice',
                'pharmacy_invoices.invoice_number',
                'pharmacy_invoices.movement_type',
                'pharmacy_invoices.payment_method',
                'pharmacy_invoices.paid_value',
                'pharmacy_invoices.total_amount',
                'stores.name as store_name',
                'suppliers.name as supplier_name',
                'pharmacy_invoices.count_items_in_invoice as items_count',
                DB::raw("DATE_FORMAT(pharmacy_invoices.date, '%Y-%m-%d') as date"),

            )
            ->leftJoin('stores', 'stores.id', '=', 'pharmacy_invoices.store_id')
            ->leftJoin('suppliers', 'suppliers.id', '=', 'pharmacy_invoices.supplier_id')
            ->where('pharmacy_invoices.clinic_id', $clinicId)
            ->where('pharmacy_invoices.invoice_type', '=', 'purchases')
            ->where(function ($query) use ($searchQuery) {
                if (!empty($searchQuery)) {
                    $query->where(function ($que) use ($searchQuery) {
                        $que->where('pharmacy_invoices.invoice_number', 'like', '%' . $searchQuery . '%')
                            ->orWhere('pharmacy_invoices.date', 'like', '%' . $searchQuery . '%')
                            ->orWhere('stores.name', 'like', '%' . $searchQuery . '%')
                            ->orWhere('suppliers.name', 'like', '%' . $searchQuery . '%')
                        ;
                    });
                }
            })
            ->groupBy('pharmacy_invoices.id')
            ->get()
        ;

        return view('pharmacy.purchase_invoices.search', compact('purchaseInvoices'));

    }


    //this method to get tax when buy items and available details when sale item
    public function getItemById(Request $request)
    {
        $drugId = $request->drug_id;
        if ($drugId == '') {
            return '';
        }

         $drug = Drugs::query()
                            ->select(
                                'drugs.id',
                                'drug_clinics_taxes.tax',
                                'drug_sections.price_of_grand_unit',
                                DB::raw('SUM(pharmacy_invoice_items.quantity) as balance')
                            )
                            ->leftJoin('drug_clinics_taxes','drug_clinics_taxes.drug_id','=','drugs.parent_id')
                            ->leftJoin('drug_sections','drug_sections.drug_id','=','drugs.id')
                            ->leftJoin('pharmacy_invoice_items', 'pharmacy_invoice_items.drug_id', '=', 'drugs.id')
                            ->where('drugs.id',$drugId)
                            ->when($request->store_id, function ($query) use ($request){
                                $query
                                    ->leftJoin('pharmacy_invoices','pharmacy_invoices.id','=','pharmacy_invoice_items.pharmacy_invoice_id')
                                    ->where('pharmacy_invoices.movement_type','=', 'purchases')
                                    ->where('pharmacy_invoices.store_id','=', $request->store_id);
                            })
                            ->first();

        return json_encode($drug);
    }


}
