<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\ItemUnitRequest;
use App\Models\ItemUnit;
use Illuminate\Http\Request;

class ItemUnitController extends Controller
{
    public function index()
    {
        $itemUnits = ItemUnit::query()->select('id', 'name')->get();
        return view('pharmacy.item_units.index', compact('itemUnits'));
    }

    public function store(ItemUnitRequest $request)
    {
        ItemUnit::query()->create([
            'name'        => $request->name,
            'clinic_id'   => auth()->user()->parent_id,
            'pharmacy_id' => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.created'));
        return redirect()->back();
    }


    public function update($itemUnitId, ItemUnitRequest $request)
    {
        $itemUnit = ItemUnit::query()->findOrFail($itemUnitId);
        if(!isset($itemUnit)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }
        $itemUnit->update([
            'name'        => $request->name,
            'clinic_id'   => auth()->user()->parent_id,
            'pharmacy_id' => auth()->user()->id,
        ]);
        session()->flash('success', trans('pharmacy.updated'));
        return redirect()->back();
    }

    public function delete($itemUnitId)
    {
        $itemUnit = ItemUnit::query()->findOrFail($itemUnitId);
        if(!isset($itemUnit)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $itemUnit->delete();

        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $searchQuery = $request->query('query');

        $itemUnits = ItemUnit::query()
                             ->select('id', 'name')
                             ->where(function ($query) use ($searchQuery) {
                                if (!empty($searchQuery)) {
                                    $query->where(function ($que) use ($searchQuery) {
                                        $que->where('name', 'like', '%' . $searchQuery . '%');
                                    });
                                }
                             })->get();

        return view('pharmacy.item_units.search', compact('itemUnits'));
    }

}
