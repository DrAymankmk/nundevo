<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\SaleInvoiceRequest;
use App\Models\AccountsTree;
use App\Models\Customer;
use App\Models\Drugs;
use App\Models\PharmacyInvoice;
use App\Models\PharmacyInvoiceItem;
use App\Models\SaleInvoice;
use App\Models\SaleInvoiceItem;
use App\Models\Store;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class SaleInvoiceController extends Controller
{
    public function index()
    {
        $clinicId = auth()->user()->parent_id;
        $data['saleInvoices'] = PharmacyInvoice::query()
               ->select(
                 'pharmacy_invoices.id',
                 'pharmacy_invoices.is_saved_invoice',
                 'pharmacy_invoices.invoice_number',
                 'pharmacy_invoices.movement_type',
                 'pharmacy_invoices.total_amount',
                 'pharmacy_invoices.paid_value',
                 'customers.name as customer_name',
                 'pharmacy_invoices.count_items_in_invoice as items_count',
                 DB::raw("DATE_FORMAT(pharmacy_invoices.date, '%Y-%m-%d') as date"),
               )
            ->where('pharmacy_invoices.clinic_id', $clinicId)
            ->where('pharmacy_invoices.invoice_type','=','sales')
            ->leftJoin('customers', 'pharmacy_invoices.customer_id', '=', 'customers.id')
            ->groupBy('pharmacy_invoices.id')
            ->get();
        return view('pharmacy.sale_invoices.index', $data);
    }

    public function create()
    {
        $clinicId          = auth()->user()->parent_id;
        $data['drugs']    = Drugs::query()
                                 ->select('id', 'name_ar','name_en','parent_id')
                                 ->whereNotNull('parent_id')->get();

        $data['customers']    = Customer::query()
                                 ->where('clinic_id', '=', $clinicId)
                                 ->select('id', 'name')->get();

        $data['stores'] = Store::query()
                               ->where('clinic_id', '=', $clinicId)
                               ->select('id', 'name')->get();

        $data['accountTrees']    = AccountsTree::query()
                                        ->where('clinic_id', '=', $clinicId)
                                        ->select('id', 'name_ar','name_en')->get();
        return view('pharmacy.sale_invoices.create',$data);
    }

    public function store(SaleInvoiceRequest $request)
    {

        try {
            DB::beginTransaction(); // Start transaction

            $saleInvoice = PharmacyInvoice::storeInvoice($request);

            $discount              = [];
            $netTotal              = [];
            $netTotalAfterDiscount = [];
            $taxValue              = [];
            $totalAmount           = [];


            if($request->drug_id){
                foreach ($request->drug_id as $index => $drugId){

                    $quantity           = floatval($request->quantity[$index]);
                    $price              = floatval($request->price[$index]);
                    $percentageDiscount = floatval($request->percentage_discount[$index]) ?? 0;
                    $valueDiscount      = floatval($request->value_discount[$index]) ?? 0;
                    $discount[$index]   = ($quantity * $price * $percentageDiscount / 100) + $valueDiscount;

                    $netTotal[$index]              = $quantity * $price;
                    $netTotalAfterDiscount[$index] = $netTotal[$index] - $discount[$index];
                    $taxValue[$index]              = ($netTotal[$index] - $discount[$index]) * floatval($request->tax[$index]) / 100;
                    $totalAmount[$index]           = ($netTotal[$index] - $discount[$index]) + $taxValue[$index];

                    if($request->quantity[$index] != '')
                    {
                        PharmacyInvoiceItem::storeInvoiceItem($request, $saleInvoice->id, $index, $netTotal[$index], $netTotalAfterDiscount[$index], $taxValue[$index], $totalAmount[$index]);
                    }
                }

                $saleInvoice->net_total                = array_sum($netTotal);
                $saleInvoice->net_total_after_discount = array_sum($netTotalAfterDiscount);
                $saleInvoice->tax_value                = array_sum($taxValue);
                $saleInvoice->total_amount             = array_sum($totalAmount);

                $saleInvoice->save();
            }

            DB::commit(); // Commit transaction
            session()->flash('success', trans('pharmacy.created'));
            return redirect()->route('pharmacy.sale-invoice.index');

        }
        catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }
    }

    public function edit($pharmacyInvoiceId)
    {
        $data['saleInvoice'] = PharmacyInvoice::query()->findOrFail($pharmacyInvoiceId);

        if(!isset($data['saleInvoice'])){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $clinicId          = auth()->user()->parent_id;
        $data['drugs']    = Drugs::query()
                                 ->select('id', 'name_ar','name_en','parent_id')
                                 ->whereNotNull('parent_id')->get();

        $data['customers']    = Customer::query()
                                        ->where('clinic_id', '=', $clinicId)
                                        ->select('id', 'name')->get();

        $data['stores'] = Store::query()
                               ->where('clinic_id', '=', $clinicId)
                               ->select('id', 'name')->get();

        $data['accountTrees']    = AccountsTree::query()
                                               ->where('clinic_id', '=', $clinicId)
                                               ->select('id', 'name_ar','name_en')->get();

        return view('pharmacy.sale_invoices.edit',$data);

    }


    public function update(SaleInvoiceRequest $request, $pharmacyInvoiceId)
    {
        try {
            $pharmacyInvoice = PharmacyInvoice::query()->findOrFail($pharmacyInvoiceId);

            if(!isset($pharmacyInvoice)){
                session()->flash('error', trans('pharmacy.not_found'));
                return redirect()->back();
            }

            DB::beginTransaction(); // Start transaction


            PharmacyInvoice::updateInvoice($request);


            $discount              = [];
            $netTotal              = [];
            $netTotalAfterDiscount = [];
            $taxValue              = [];
            $totalAmount           = [];

            if($request->drug_id){
                foreach ($request->drug_id as $index => $drugId){


                    $quantity           = floatval($request->quantity[$index]);
                    $price              = floatval($request->price[$index]);
                    $percentageDiscount = floatval($request->percentage_discount[$index]) ?? 0;
                    $valueDiscount      = floatval($request->value_discount[$index]) ?? 0;
                    $discount[$index]   = ($quantity * $price * $percentageDiscount / 100) + $valueDiscount;

                    $netTotal[$index]              = $quantity * $price;
                    $netTotalAfterDiscount[$index] = $netTotal[$index] - $discount[$index];
                    $taxValue[$index]              = ($netTotal[$index] - $discount[$index]) * floatval($request->tax[$index]) / 100;
                    $totalAmount[$index]           = ($netTotal[$index] - $discount[$index]) + $taxValue[$index];
                    if($request->quantity[$index] != ''){
                        PharmacyInvoiceItem::updateInvoiceItem($request, $pharmacyInvoiceId, $index, $netTotal[$index], $netTotalAfterDiscount[$index], $taxValue[$index], $totalAmount[$index]);
                    }
                }

                $pharmacyInvoice->net_total                = array_sum($netTotal);
                $pharmacyInvoice->net_total_after_discount = array_sum($netTotalAfterDiscount);
                $pharmacyInvoice->tax_value                = array_sum($taxValue);
                $pharmacyInvoice->total_amount             = array_sum($totalAmount);

                $pharmacyInvoice->save();
            }
            DB::commit(); // Commit transaction
            session()->flash('success', trans('pharmacy.created'));
            return redirect()->route('pharmacy.sale-invoice.index');

        }catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }

    }

    public function delete($saleInvoiceId)
    {
        $pharmacyInvoice = PharmacyInvoice::query()->findOrFail($saleInvoiceId);

        if(!isset($pharmacyInvoice)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $pharmacyInvoice->delete();
        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $clinicId = auth()->user()->parent_id;

        $searchQuery = $request->query('query');


        $data['saleInvoices'] = PharmacyInvoice::query()
            ->select(
                'pharmacy_invoices.id',
                'pharmacy_invoices.is_saved_invoice',
                'pharmacy_invoices.invoice_number',
                'pharmacy_invoices.movement_type',
                'pharmacy_invoices.total_amount',
                'pharmacy_invoices.paid_value',
                'customers.name as customer_name',
                'pharmacy_invoices.count_items_in_invoice as items_count',
                DB::raw("DATE_FORMAT(pharmacy_invoices.date, '%Y-%m-%d') as date"),
            )
            ->leftJoin('customers', 'pharmacy_invoices.customer_id', '=', 'customers.id')
            ->where(function ($query) use ($searchQuery) {
                if (!empty($searchQuery)) {
                    $query->where(function ($que) use ($searchQuery) {
                        $que->where('pharmacy_invoices.invoice_number', 'like', '%' . $searchQuery . '%')
                            ->orWhere('pharmacy_invoices.date', 'like', '%' . $searchQuery . '%')
                            ->orWhere('customers.name', 'like', '%' . $searchQuery . '%')
                        ;
                    });
                }
            })
            ->where('pharmacy_invoices.clinic_id', $clinicId)
            ->where('pharmacy_invoices.invoice_type', '=', 'sales')
            ->groupBy('pharmacy_invoices.id')
            ->get()
        ;
        return view('pharmacy.sale_invoices.search', $data);


    }

    public function getDrugsExistedInStore(Request  $request)
    {
        $storeId = $request->store_id;
        $clinicId = auth()->user()->parent_id;
        if($storeId == '')
            return '';

        $data['drugs']    = Drugs::query()
                                 ->select('id', 'name_ar','name_en','parent_id')
                                 ->whereNotNull('parent_id')->get();

        $data['drugsInStore'] = PharmacyInvoiceItem::query()
            ->select(
                'pharmacy_invoice_items.id as pharmacy_invoice_item_id',
                'pharmacy_invoice_items.drug_id as drug_id',
                'drug_sections.price_of_grand_unit as price',
                'drug_clinics_taxes.tax as tax',
                DB::raw("SUM(pharmacy_invoice_items.quantity) as balance"),
            )
            ->leftJoin('pharmacy_invoices','pharmacy_invoices.id','=','pharmacy_invoice_items.pharmacy_invoice_id')
            ->leftJoin('drug_sections','drug_sections.drug_id','=','pharmacy_invoice_items.drug_id')
            ->leftJoin('drug_clinics_taxes', function ($join) use ($clinicId){
                $join->on('drug_clinics_taxes.drug_id','=','pharmacy_invoice_items.drug_id')
                    ->where('drug_clinics_taxes.clinic_id',$clinicId);
            })
            ->where('pharmacy_invoices.store_id','=', $storeId)
            ->where('pharmacy_invoices.movement_type','=', 'purchases')
            ->groupBy('pharmacy_invoice_items.drug_id')
            ->get();

        return view('pharmacy.sale_invoices.get_drugs_by_store', $data);
    }


}
