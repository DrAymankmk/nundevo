<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy\Reports;

use App\Http\Controllers\Controller;
use App\Models\Clinic;
use App\Models\Customer;
use App\Models\Drugs;
use App\Models\Inventory;
use App\Models\InventoryRecord;
use App\Models\InventoryRecordItem;
use App\Models\PharmacyInvoice;
use App\Models\PharmacyInvoiceItem;
use App\Models\PurchaseInvoice;
use App\Models\SaleInvoice;
use App\Models\Store;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function getSuppliersAndClientsAccountsReport()
    {
        return view('pharmacy.reports.get_suppliers_and_clients_accounts');
    }

    public function dataSuppliersAndClientsAccountsReport(Request $request)
    {
        $clinicId =auth()->user()->parent_id;
        $accountType = $request->account_type;
        if($request->account_type == '')
        {
            return '';
        }
         $suppliersAndClients =
             PharmacyInvoice::query()
                            ->when($request->account_type == 'suppliers', function ($query) {
                                $query->leftJoin('suppliers', 'suppliers.id', '=', 'pharmacy_invoices.supplier_id')
                                    ->where('pharmacy_invoices.invoice_type', '=', 'purchases')
                                    ->select(
                                        'pharmacy_invoices.id as pharmacy_invoice_id',
                                        DB::raw('SUM(pharmacy_invoices.paid_value) as paid_value'),
                                        DB::raw('SUM(pharmacy_invoices.total_amount) as total_amount'),
                                        'suppliers.name as name',
                                        'suppliers.phone as phone',
                                        'suppliers.id as id',
                                    )
                                      ->groupBy('suppliers.id');
                            })
                            ->when($request->account_type == 'clients', function ($query) {
                                    $query->leftJoin('customers', 'customers.id', '=', 'pharmacy_invoices.customer_id')
                                          ->where('pharmacy_invoices.invoice_type', '=', 'sales')
                                    ->select(
                                        'pharmacy_invoices.id as pharmacy_invoice_id',
                                        DB::raw('SUM(pharmacy_invoices.paid_value) as paid_value'),
                                        DB::raw('SUM(pharmacy_invoices.total_amount) as total_amount'),
                                        'customers.name as name',
                                        'customers.phone as phone',
                                        'customers.id as id',
                                    )
                                      ->groupBy('customers.id');
                            })
                            ->where('pharmacy_invoices.clinic_id', '=', $clinicId)
                            ->get();


        return view('pharmacy.reports.table_suppliers_and_clients',compact('suppliersAndClients'));
    }


    public function getSalesReport()
    {
        $data['pharmacies'] = Clinic::query()
            ->select('id','name')
            ->where('app_type','=',5)
            ->get();

        $data['doctors'] = Clinic::query()
                                    ->select('id','name')
                                    ->where('app_type','=',3)
                                    ->get();

        $data['medicineDepartments'] = Drugs::query()
            ->select('id','name_ar','name_en')
            ->whereNull('parent_id')
            ->get();

        $data['drugs'] = Drugs::query()
                                    ->select('id','name_ar','name_en')
                                    ->whereNotNull('parent_id')
                                    ->get();

        $data['users'] = User::query()->select('id','name')->get();

        return view('pharmacy.reports.get_sales_report', $data);
    }

    public function dataSalesReport(Request $request)
    {
        $clinicId = auth()->user()->parent_id;
        $fromDate = date('Y-m-d', strtotime(str_replace('/', '-', $request->from_date)));
        $toDate   = date('Y-m-d', strtotime(str_replace('/', '-', $request->to_date)));
        $pharmacyInvoiceItems = PharmacyInvoiceItem::query()
            ->select(
                'pharmacy_invoice_items.id as pharmacy_invoice_item_id',
                'drugs.name_ar as drug_name_ar',
                'drugs.name_en as drug_name_en',
                'pharmacy_invoice_items.price as price',
                'pharmacy_invoice_items.quantity as quantity',
                'pharmacy_invoices.movement_type as movement_type',
                'pharmacy_invoices.date as date',
                'clinics.name as doctor_name',
                'item_units.name as item_unit_name',

            )
            ->leftJoin('pharmacy_invoices','pharmacy_invoices.id','=','pharmacy_invoice_items.pharmacy_invoice_id')
            ->leftJoin('drugs','drugs.id','=','pharmacy_invoice_items.drug_id')
            ->leftJoin('clinics','clinics.id','=','pharmacy_invoices.doctor_id')
            ->leftJoin('drug_sections','drug_sections.drug_id','pharmacy_invoice_items.drug_id')
            ->leftJoin('item_units','item_units.id','drug_sections.grand_unit_id')
            ->whereBetween('pharmacy_invoices.date',[$fromDate, $toDate])
            ->where('pharmacy_invoices.invoice_type','!=','purchases')
            ->where('pharmacy_invoices.clinic_id', '=', $clinicId)
             ->when($request->pharmacy, function ($query) use ($request) {
                 $query->where('pharmacy_invoices.pharmacy_id', '=', $request->pharmacy);
             })
             ->when($request->group_id, function ($query) use ($request) {
                 $drugIds = Drugs::query()->where('parent_id','=', $request->group_id)
                     ->pluck('id')->toArray();
                 $query->whereIn('pharmacy_invoice_items.drug_id', $drugIds);
             })
             ->when($request->drug_id, function ($query) use ($request) {
                 $query->where('pharmacy_invoice_items.drug_id', '=', $request->drug_id);
             })
             ->when($request->movement_type, function ($query) use ($request) {
                 if($request->movement_type == 'all'){
                     $query->whereNotIn('pharmacy_invoices.movement_type',['purchases','purchases_return']) ;
                 }else {
                     $query->where('pharmacy_invoices.movement_type', '=', $request->movement_type);
                 }
             })
             ->when($request->patient_id, function ($query) use ($request) {
                 $query->where('pharmacy_invoices.patient_id', '=', $request->patient_id);
             })
             ->when($request->doctor_id, function ($query) use ($request) {
                 $query->where('pharmacy_invoices.doctor_id', '=', $request->doctor_id);
             })
             ->when($request->tax, function ($query) use ($request){
                 if($request->tax == 'all'){
                     $query->where('pharmacy_invoice_items.tax', '!=', null);
                 }else if($request->tax == 'tax_is_not_zero'){
                     $query->where('pharmacy_invoice_items.tax', '!=', 0);
                 }else{
                     $query->where('pharmacy_invoice_items.tax', '==', 0);
                 }
             })
            ->groupBy('pharmacy_invoice_items.id')
            ->get();

        return view('pharmacy.reports.table_sales_report',compact('pharmacyInvoiceItems'));

    }

    public function getSalesInvoiceReport()
    {
        $data['pharmacies'] = Clinic::query()
                                    ->select('id','name')
                                    ->where('app_type','=',5)
                                    ->get();

        $data['doctors'] = Clinic::query()
                                 ->select('id','name')
                                 ->where('app_type','=',3)
                                 ->get();

        $data['medicineDepartments'] = Drugs::query()
                                            ->select('id','name_ar','name_en')
                                            ->whereNull('parent_id')
                                            ->get();

        $data['customers'] = Customer::query()->select('id','name')->get();

        $data['invoices'] = PharmacyInvoice::query()
                              ->select('id','invoice_number')
                              ->where('invoice_type','!=','purchases')
                              ->get();

        $data['users'] = User::query()->select('id','name')->get();

        return view('pharmacy.reports.get_sales_invoice_report', $data);
    }


    public function dataSalesInvoiceReport(Request $request)
    {
        $clinicId = auth()->user()->parent_id;
        $fromDate = date('Y-m-d', strtotime(str_replace('/', '-', $request->from_date)));
        $toDate   = date('Y-m-d', strtotime(str_replace('/', '-', $request->to_date)));

         $invoices = PharmacyInvoice::query()
            ->select(
                'pharmacy_invoices.id as invoice_id',
                'pharmacy_invoices.invoice_number as invoice_number',
                'pharmacy_invoices.date as date',
                'pharmacy_invoices.invoice_type as invoice_type',
                'pharmacy_invoices.total_amount as total_amount',
                'pharmacy_invoices.paid_value as paid_value',
                'pharmacy_invoices.movement_type as movement_type',
                'customers.name as customer_name',
                'users.name as patient_name',
                'pharmacy_invoices.count_items_in_invoice as items_count',
            )
            ->leftJoin('customers','customers.id','=','pharmacy_invoices.customer_id')
            ->leftJoin('users','users.id','=','pharmacy_invoices.patient_id')
            ->whereBetween('pharmacy_invoices.date',[$fromDate, $toDate])
            ->where('pharmacy_invoices.invoice_type','!=','purchases')
            ->where('pharmacy_invoices.clinic_id', '=', $clinicId)
            ->when($request->pharmacy, function ($query) use ($request) {
                $query->where('pharmacy_invoices.pharmacy_id', '=', $request->pharmacy);
            })
            ->when($request->customer_id, function ($query) use ($request) {
                $query->where('pharmacy_invoices.customer_id', '=', $request->customer_id);
            })
            ->when($request->doctor_id, function ($query) use ($request) {
                $query->where('pharmacy_invoices.doctor_id', '=', $request->doctor_id);
            })
            ->when($request->movement_type, function ($query) use ($request) {
                if($request->movement_type == 'all'){
                    $query->whereNotIn('pharmacy_invoices.movement_type',['purchases','purchases_return']) ;
                }else {
                    $query->where('pharmacy_invoices.movement_type', '=', $request->movement_type);
                }
            })

            ->when($request->invoice_id, function ($query) use ($request) {
                $query->where('pharmacy_invoices.id', '=', $request->invoice_id);
            })
            ->groupBy('pharmacy_invoices.id')
            ->get();

        return view('pharmacy.reports.table_sales_invoices_report',compact('invoices'));

    }

    public function getPurchaseReport()
    {
        $data['suppliers'] = Supplier::query()->select('id','name')->get();

        $data['medicineDepartments'] = Drugs::query()
                                            ->select('id','name_ar','name_en')
                                            ->whereNull('parent_id')
                                            ->get();

        $data['drugs'] = Drugs::query()
                              ->select('id','name_ar','name_en')
                              ->whereNotNull('parent_id')
                              ->get();

        return view('pharmacy.reports.get_purchase_report', $data);

    }

    public function dataPurchaseReport(Request $request)
    {
        $clinicId = auth()->user()->parent_id;
        $fromDate = date('Y-m-d', strtotime(str_replace('/', '-', $request->from_date)));
        $toDate   = date('Y-m-d', strtotime(str_replace('/', '-', $request->to_date)));


        $purchaseInvoiceItems = PharmacyInvoiceItem::query()
                                                  ->select(
                                                      'pharmacy_invoice_items.id as pharmacy_invoice_item_id',
                                                      'drugs.name_ar as drug_name_ar',
                                                      'drugs.name_en as drug_name_en',
                                                      'pharmacy_invoice_items.price as price',
                                                      'pharmacy_invoice_items.quantity as quantity',
                                                      'item_units.name as item_unit_name',
                                                      'pharmacy_invoices.date as date',
                                                      'pharmacy_invoices.movement_type as movement_type',
                                                      'suppliers.name as supplier_name',
                                                  )
                                                  ->leftJoin('pharmacy_invoices','pharmacy_invoices.id','=','pharmacy_invoice_items.pharmacy_invoice_id')
                                                  ->leftJoin('suppliers','suppliers.id','=','pharmacy_invoices.supplier_id')
                                                  ->leftJoin('drugs','drugs.id','=','pharmacy_invoice_items.drug_id')
                                                  ->leftJoin('drug_sections','drug_sections.drug_id','pharmacy_invoice_items.drug_id')
                                                  ->leftJoin('item_units','item_units.id','drug_sections.grand_unit_id')
                                                  ->whereBetween('pharmacy_invoices.date',[$fromDate, $toDate])
                                                  ->where('pharmacy_invoices.invoice_type','=','purchases')
                                                  ->where('pharmacy_invoices.clinic_id', '=', $clinicId)
                                                  ->when($request->supplier_id, function ($query) use ($request){

                                                      if($request->supplier_id == 'all'){
                                                          $query->where('pharmacy_invoices.supplier_id', '!=', $request->supplier_id);
                                                      }else{
                                                          $query->where('pharmacy_invoices.supplier_id', '=', $request->supplier_id);
                                                      }
                                                  })
                                                  ->when($request->group_id, function ($query) use ($request) {
                                                      $drugIds = Drugs::query()->where('parent_id','=', $request->group_id)
                                                                      ->pluck('id')->toArray();
                                                      $query->whereIn('pharmacy_invoice_items.drug_id', $drugIds);
                                                  })
                                                  ->when($request->drug_id, function ($query) use ($request) {
                                                      $query->where('pharmacy_invoice_items.drug_id', '=', $request->drug_id);
                                                  })
                                                  ->when($request->movement_type, function ($query) use ($request) {
                                                      if($request->movement_type == 'all'){
                                                          $query->whereNotIn('pharmacy_invoices.movement_type',['sales','sales_return']) ;
                                                      }else {
                                                          $query->where('pharmacy_invoices.movement_type', '=', $request->movement_type);
                                                      }
                                                  })
                                                  ->when($request->tax, function ($query) use ($request){
                                                      if($request->tax == 'all'){
                                                          $query->where('pharmacy_invoice_items.tax', '!=', null);
                                                      }else if($request->tax == 'tax_is_not_zero'){
                                                          $query->where('pharmacy_invoice_items.tax', '!=', 0);
                                                      }else{
                                                          $query->where('pharmacy_invoice_items.tax', '==', 0);
                                                      }
                                                  })
                                                  ->groupBy('pharmacy_invoice_items.id')
                                                  ->get();

        return view('pharmacy.reports.table_purchase_report',compact('purchaseInvoiceItems'));
    }


    public function getPurchaseInvoiceReport()
    {
        $data['suppliers'] = Supplier::query()->select('id','name')->get();
        return view('pharmacy.reports.get_purchase_invoice_report', $data);
    }

    public function dataPurchaseInvoiceReport(Request $request)
    {
        $clinicId = auth()->user()->parent_id;
        $fromDate = date('Y-m-d', strtotime(str_replace('/', '-', $request->from_date)));
        $toDate   = date('Y-m-d', strtotime(str_replace('/', '-', $request->to_date)));

        $invoices = PharmacyInvoice::query()
            ->select(
                'pharmacy_invoices.id as invoice_id',
                'pharmacy_invoices.invoice_number as invoice_number',
                'pharmacy_invoices.date as date',
                'pharmacy_invoices.invoice_type as invoice_type',
                'pharmacy_invoices.total_amount as total_amount',
                'pharmacy_invoices.paid_value as paid_value',
                'pharmacy_invoices.movement_type as movement_type',
                'suppliers.name as supplier_name',
                'pharmacy_invoices.count_items_in_invoice as items_count',

            )
            ->leftJoin('suppliers', 'suppliers.id', '=', 'pharmacy_invoices.supplier_id')
            ->where('pharmacy_invoices.clinic_id', '=', $clinicId)
            ->where('pharmacy_invoices.invoice_type', '=', 'purchases')
            ->whereBetween('pharmacy_invoices.date', [$fromDate, $toDate])
            ->when($request->supplier_id, function ($query) use ($request) {
                if ($request->supplier_id == 'all') {
                    $query->where('pharmacy_invoices.supplier_id', '!=', $request->supplier_id);
                }
                else {
                    $query->where('pharmacy_invoices.supplier_id', '=', $request->supplier_id);
                }
            })
            ->when($request->movement_type, function ($query) use ($request) {
                if ($request->movement_type == 'all') {
                    $query->whereNotIn('pharmacy_invoices.movement_type', ['sales', 'sales_return']);
                }
                else {
                    $query->where('pharmacy_invoices.movement_type', '=', $request->movement_type);
                }
            })
            ->groupBy('pharmacy_invoices.id')
            ->get();
        return view('pharmacy.reports.table_purchase_invoices_report',compact('invoices'));
    }

    public function getSuppliersReport()
    {

        $data['medicineDepartments'] = Drugs::query()
                                            ->select('id','name_ar','name_en')
                                            ->whereNull('parent_id')
                                            ->get();
        $data['drugs'] = Drugs::query()
                              ->select('id','name_ar','name_en')
                              ->whereNotNull('parent_id')
                              ->get();

        return view('pharmacy.reports.get_suppliers_report', $data);

    }

    public function dataSupplierReport(Request $request)
    {
        $clinicId = auth()->user()->parent_id;
        $fromDate = date('Y-m-d', strtotime(str_replace('/', '-', $request->from_date)));
        $toDate   = date('Y-m-d', strtotime(str_replace('/', '-', $request->to_date)));


        $suppliers = PharmacyInvoiceItem::query()
            ->select(
                'suppliers.name as supplier_name',
                'suppliers.phone as supplier_phone',
                'suppliers.representative_name as representative_name',
                'suppliers.representative_phone as representative_phone',
            )
            ->leftJoin('pharmacy_invoices','pharmacy_invoices.id','=', 'pharmacy_invoice_items.pharmacy_invoice_id')
            ->leftJoin('suppliers','suppliers.id','=','pharmacy_invoices.supplier_id')
            ->leftJoin('drug_sections','drug_sections.drug_id','pharmacy_invoice_items.drug_id')
            ->leftJoin('item_units','item_units.id','drug_sections.grand_unit_id')
            ->whereBetween('pharmacy_invoices.date',[$fromDate, $toDate])
            ->where('pharmacy_invoices.clinic_id', '=', $clinicId)
            ->where('pharmacy_invoices.invoice_type','=','purchases')
            ->when($request->group_id, function ($query) use ($request) {
                $drugIds = Drugs::query()->where('parent_id','=', $request->group_id)
                                ->pluck('id')->toArray();
                $query->whereIn('pharmacy_invoice_items.drug_id', $drugIds);
            })
            ->when($request->drug_id, function ($query) use ($request) {
                $query->where('pharmacy_invoice_items.drug_id', '=', $request->drug_id);
            })
            ->groupBy('suppliers.id')
            ->get();

        return view('pharmacy.reports.table_suppliers_report',compact('suppliers'));

    }

    public function getDrugsReport()
    {
        $data['stores'] = Store::query()->select('id','name')->get();

        $data['medicineDepartments'] = Drugs::query()
                                            ->select('id','name_ar','name_en')
                                            ->whereNull('parent_id')
                                            ->get();
        $data['suppliers'] = Supplier::query()
                              ->select('id','name')
                              ->get();

        $data['drugs'] = Drugs::query()
                                     ->select('id','name_ar','name_en')
                                     ->get();

        return view('pharmacy.reports.get_drugs_report', $data);

    }

    public function dataDrugsReport(Request $request)
    {
        $clinicId = auth()->user()->parent_id;


         $drugs = PharmacyInvoiceItem::query()
                                    ->select(
                                        'drugs.id as drug_id',
                                        'drugs.name_ar as drug_name_ar',
                                        'drugs.name_en as drug_name_en',
                                        'sections.name_ar as section_name_ar',
                                        'sections.name_en as section_name_en',
                                        'drug_sections.price_of_grand_unit as price',
                                        'stores.name as store_name',
                                        'suppliers.name as supplier_name',
                                        'drug_sections.limit_of_deficiencies as limit_of_deficiencies',
                                        DB::raw('SUM(CASE WHEN pharmacy_invoices.movement_type = "purchases" THEN pharmacy_invoice_items.quantity ELSE 0 END) as buying_quantity'),
                                        DB::raw('SUM(CASE WHEN pharmacy_invoices.movement_type = "sales" THEN pharmacy_invoice_items.quantity ELSE 0 END) as selling_quantity')
                                    )
                                    ->leftJoin('pharmacy_invoices', 'pharmacy_invoices.id', '=', 'pharmacy_invoice_items.pharmacy_invoice_id')
                                    ->leftJoin('drugs', 'drugs.id', '=', 'pharmacy_invoice_items.drug_id')
                                    ->leftJoin('drugs as sections', 'sections.id', '=', 'drugs.parent_id')
                                    ->leftJoin('drug_sections', 'drug_sections.drug_id', '=', 'drugs.id')
                                    ->leftJoin('suppliers', 'suppliers.id', '=', 'drug_sections.supplier_id') // Assuming you have an inventories table
                                    ->leftJoin('stores', 'stores.id', '=', 'pharmacy_invoices.store_id')
                                    ->where('pharmacy_invoices.clinic_id', $clinicId)
                                    ->when($request->store_id, function ($query) use ($request) {
                                        if($request->store_id == 'all'){
                                            $query->where('pharmacy_invoices.store_id', '!=', '');
                                        }else{
                                            $query->where('pharmacy_invoices.store_id', $request->store_id);
                                        }
                                    })
                                    ->when($request->group_id, function ($query) use ($request) {
                                        $query->where('drugs.parent_id',$request->group_id);
                                    })
                                    ->when($request->drug_id, function ($query) use ($request) {
                                        $query->where('drugs.id',$request->drug_id);
                                    })
                                    ->when($request->supplier_id, function ($query) use ($request) {
                                        $query->where('pharmacy_invoices.supplier_id',$request->supplier_id);
                                    })
                                    ->groupBy('drugs.id')
                                    ->get();

        return view('pharmacy.reports.table_drugs_report', compact('drugs'));

    }


    public function getDrugsMovementReport()
    {

        $data['medicineDepartments'] = Drugs::query()
                                            ->select('id','name_ar','name_en')
                                            ->whereNull('parent_id')
                                            ->get();
        $data['drugs'] = Drugs::query()
                              ->select('id','name_ar','name_en')
                              ->whereNotNull('parent_id')
                              ->get();

        return view('pharmacy.reports.get_drugs_movement_report', $data);

    }

    public function dataDrugsMovementReport(Request $request)
    {
        $clinicId = auth()->user()->parent_id;
        $fromDate = date('Y-m-d', strtotime(str_replace('/', '-', $request->from_date)));
        $toDate   = date('Y-m-d', strtotime(str_replace('/', '-', $request->to_date)));


         $pharmacyInvoiceItems = PharmacyInvoiceItem::query()
            ->select(
                'drugs.id',
                'drugs.name_ar as drug_name_ar',
                'drugs.name_en as drug_name_en',
                'sections.name_ar as section_name_ar',
                'sections.name_en as section_name_en',
                'pharmacy_invoice_items.price as price',
                'item_units.name as item_unit_name',
                'pharmacy_invoices.date as date',
                'pharmacy_invoices.movement_type as movement_type',
                DB::raw('SUM(pharmacy_invoice_items.quantity) as quantity')
            )
            ->leftJoin('pharmacy_invoices', 'pharmacy_invoices.id', '=', 'pharmacy_invoice_items.pharmacy_invoice_id')
            ->leftJoin('drugs', 'drugs.id', '=', 'pharmacy_invoice_items.drug_id')
            ->leftJoin('drugs as sections', 'sections.id', '=', 'drugs.parent_id')
            ->leftJoin('drug_sections', 'drug_sections.drug_id', '=', 'pharmacy_invoice_items.drug_id')
            ->leftJoin('item_units', 'item_units.id', '=', 'drug_sections.grand_unit_id')
            ->whereBetween('pharmacy_invoices.date', [$fromDate, $toDate])
            ->where('pharmacy_invoices.clinic_id', '=', $clinicId)
            ->when($request->group_id, function ($query) use ($request) {
                $drugIds = Drugs::query()->where('parent_id', '=', $request->group_id)
                                ->pluck('id')->toArray()
                ;
                $query->whereIn('pharmacy_invoice_items.drug_id', $drugIds);
            })
            ->when($request->drug_id, function ($query) use ($request) {
                $query->where('pharmacy_invoice_items.drug_id', '=', $request->drug_id);
            })
            ->groupBy('drugs.id', 'pharmacy_invoices.movement_type', 'pharmacy_invoices.date')
            ->get()
        ;



        return view('pharmacy.reports.table_drugs_movement_report',compact('pharmacyInvoiceItems'));

    }


    public function getPharmacyInvoiceReports()
    {

        $data['pharmacies'] = Clinic::query()
                                    ->select('id','name')
                                    ->where('app_type','=',5)
                                    ->get();



        return view('pharmacy.reports.get_pharmacy_invoices_report', $data);

    }


    public function dataPharmacyInvoiceReports(Request $request)
    {
        $clinicId = auth()->user()->parent_id;
        $fromDate = date('Y-m-d', strtotime(str_replace('/', '-', $request->from_date)));
        $toDate   = date('Y-m-d', strtotime(str_replace('/', '-', $request->to_date)));

        $invoices = PharmacyInvoice::query()
            ->select(
                'pharmacy_invoices.id as invoice_id',
                'pharmacy_invoices.invoice_number as invoice_number',
                'pharmacy_invoices.date as date',
                'pharmacy_invoices.invoice_type as invoice_type',
                'pharmacy_invoices.total_amount as total_amount',
                'pharmacy_invoices.paid_value as paid_value',
                'pharmacy_invoices.count_items_in_invoice as items_count',
                'pharmacy_invoices.movement_type as movement_type',
            )
            ->where('pharmacy_invoices.clinic_id', '=', $clinicId)
            ->whereBetween('pharmacy_invoices.date', [$fromDate, $toDate])
            ->when($request->pharmacy_id, function ($query) use ($request) {
                $query->where('pharmacy_invoices.pharmacy_id', '=', $request->pharmacy_id);
            })
            ->when($request->movement_type, function ($query) use ($request) {
                if ($request->movement_type == 'all') {
                    $query->where('pharmacy_invoices.movement_type', '!=', '');
                }
                elseif ($request->movement_type == 'purchases') {
                    $query->where('pharmacy_invoices.movement_type', '=', 'purchases');
                }
                elseif ($request->movement_type == 'purchases_return') {
                    $query->where('pharmacy_invoices.movement_type', '=', 'purchases_return');
                }
                elseif ($request->movement_type == 'sales') {
                    $query->where('pharmacy_invoices.movement_type', '=', 'sales');
                }
                else {
                    $query->where('pharmacy_invoices.movement_type', '=', 'sales_return');
                }
            })
            ->groupBy('pharmacy_invoices.id')
            ->get()
        ;

        return view('pharmacy.reports.table_pharmacy_invoices_report',compact('invoices'));
    }

    public function getWarningReports()
    {
        return view('pharmacy.reports.get_warnings_report');
    }
    public function dataWarningReports(Request $request)
    {
        $clinicId = auth()->user()->parent_id;
        $fromDate = date('Y-m-d', strtotime(str_replace('/', '-', $request->from_date)));
        $toDate   = date('Y-m-d', strtotime(str_replace('/', '-', $request->to_date)));
        $dateNow  = now()->format('Y-m-d');
         $drugs = PharmacyInvoiceItem::query()
             ->select(
                 'drugs.id as drug_id',
                 'drugs.name_ar as drug_name_ar',
                 'drugs.name_en as drug_name_en',
                 'sections.name_ar as section_name_ar',
                 'sections.name_en as section_name_en',
                 'drug_sections.price_of_grand_unit as price',
                 'drug_sections.recession_limit as recession_limit',
                 'drug_sections.limit_of_deficiencies as limit_of_deficiencies',
                 'drugs.expiration_date as expiration_date',
                 'stores.name as store_name',
                 'suppliers.name as supplier_name',
                 DB::raw('SUM(CASE WHEN pharmacy_invoices.movement_type = "purchases" THEN pharmacy_invoice_items.quantity ELSE 0 END) as buying_quantity'),
                 DB::raw('SUM(CASE WHEN pharmacy_invoices.movement_type = "sales" THEN pharmacy_invoice_items.quantity ELSE 0 END) as selling_quantity')
             )
             ->leftJoin('pharmacy_invoices', 'pharmacy_invoices.id', '=', 'pharmacy_invoice_items.pharmacy_invoice_id')
             ->leftJoin('drugs', 'drugs.id', '=', 'pharmacy_invoice_items.drug_id')
             ->leftJoin('drugs as sections', 'sections.id', '=', 'drugs.parent_id')
             ->leftJoin('drug_sections', 'drug_sections.drug_id', '=', 'drugs.id')
             ->leftJoin('suppliers', 'suppliers.id', '=', 'drug_sections.supplier_id') // Assuming you have an inventories table
             ->leftJoin('stores', 'stores.id', '=', 'pharmacy_invoices.store_id')
             ->where('pharmacy_invoices.clinic_id', $clinicId)
             ->whereBetween('pharmacy_invoices.date', [$fromDate, $toDate]);


             // Apply additional conditions based on request type
            if ($request->type) {
                if ($request->type == 'expiration_date') {
                    $drugs->where('drugs.expiration_date', '<', $dateNow);
                } else {
                    $drugs->havingRaw('SUM(CASE WHEN pharmacy_invoices.movement_type = "purchases" THEN pharmacy_invoice_items.quantity ELSE 0 END) - SUM(CASE WHEN pharmacy_invoices.movement_type = "sales" THEN pharmacy_invoice_items.quantity ELSE 0 END) > drug_sections.limit_of_deficiencies');
                }
            }
            $drugs=$drugs->groupBy('drugs.id')->get();

        return view('pharmacy.reports.table_warnings_report', compact('drugs'));
    }


    public function getPharmacyInventoryReports()
    {

        $data['pharmacies'] = Clinic::query()
                                    ->select('id','name')
                                    ->where('app_type','=',5)
                                    ->get();



        return view('pharmacy.reports.get_pharmacy_inventory_report', $data);

    }


    public function dataPharmacyInventoryReports(Request $request)
    {
        $clinicId = auth()->user()->parent_id;
        $fromDate = date('Y-m-d 00:00:00', strtotime(str_replace('/', '-', $request->from_date)));
        $toDate = date('Y-m-d 23:59:59', strtotime(str_replace('/', '-', $request->to_date)));


         $inventoryRecords = InventoryRecord::query()
            ->select(
                'inventory_records.id as inventory_record_id',
                'inventory_records.code_number as code_number',
                'clinics.name as pharmacist_name',
                'inventory_records.date_time as date_time',
            )
            ->leftJoin('clinics','clinics.id','=','inventory_records.pharmacy_id')
            ->whereBetween('inventory_records.date_time',[$fromDate, $toDate])
            ->where('inventory_records.clinic_id',$clinicId)
            ->when($request->pharmacy_id, function ($query) use ($request){
                $query->where('inventory_records.pharmacy_id',$request->pharmacy_id);
            })
            ->get();

        return view('pharmacy.reports.table_pharmacy_inventories_report',compact('inventoryRecords'));
    }

    public function getInventoryItemsReports($inventoryRecordId)
    {
        $inventoryIds = InventoryRecordItem::query()
                                           ->where('inventory_record_id',$inventoryRecordId)
            ->pluck('inventory_id')->toArray();

        $inventories = Inventory::query()
            ->select(
                'inventories.id',
                'inventories.date as date_inventory',
                'drugs.name_ar as drug_name_ar',
                'drugs.name_en as drug_name_en',
                'drugs.short_code as code',
                'stores.name as store_name',
                'inventories.quantity as actual_quantity',
                'drug_sections.price_of_grand_unit as price',
                'item_units.name as unit_name',
                DB::raw('COALESCE(SUM(CASE WHEN pharmacy_invoices.invoice_type = "purchase" THEN pharmacy_invoice_items.quantity ELSE 0 END), 0) as quantity_in_system'),
                DB::raw('drug_sections.price_of_grand_unit * inventories.quantity as total_amount'),
            )
            ->leftJoin('drugs','inventories.drug_id','=','drugs.id')
            ->leftJoin('stores','inventories.store_id','=','stores.id')
            ->leftJoin('drug_sections','inventories.drug_id','=','drug_sections.drug_id')
            ->leftJoin('item_units','drug_sections.grand_unit_id','=','item_units.id')
            ->leftJoin('pharmacy_invoice_items', 'pharmacy_invoice_items.drug_id', '=', 'drugs.id')
            ->leftJoin('pharmacy_invoices', 'pharmacy_invoices.id', '=', 'pharmacy_invoice_items.pharmacy_invoice_id')
            ->whereIn('inventories.id',$inventoryIds)
            ->groupBy('inventories.id')
            ->get();

//        return $inventories;

        return view('pharmacy.reports.get_inventory_items_report',compact('inventories'));

    }

}