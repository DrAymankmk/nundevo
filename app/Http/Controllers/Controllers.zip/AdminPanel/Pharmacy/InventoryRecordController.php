<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\InventoryRecordRequest;
use App\Models\Drugs;
use App\Models\Inventory;
use App\Models\InventoryRecord;
use App\Models\InventoryRecordItem;
use App\Models\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InventoryRecordController extends Controller
{
    public function index()
    {
         $data['inventoryRecords'] = InventoryRecord::query()
            ->select(
                'inventory_records.id',
                'inventory_records.created_by',
                'inventory_records.code_number',
                'inventory_records.created_at',
                'clinics.name as clinic_name',
            )
            ->leftJoin('clinics', 'clinics.id', '=', 'inventory_records.created_by')
            ->get();
        return view('pharmacy.inventory_records.index', $data);
    }


    public function store(InventoryRecordRequest $request)
    {
        try {
            DB::beginTransaction(); // Start transaction

            $inventoryRecord = InventoryRecord::query()->create([
                'note'        => $request->note,
                'code_number' => $request->code_number ?? null,
                'date_time'   => now(),
                'created_by'  => auth()->user()->id,
                'clinic_id'   => auth()->user()->parent_id,
                'pharmacy_id' => auth()->user()->id,
            ]);

            if($request->inventory_id){
                foreach ($request->inventory_id as $inventoryId){
                    InventoryRecordItem::query()->create([
                        'inventory_record_id' => $inventoryRecord->id,
                        'inventory_id'        => $inventoryId,
                    ]);

                    Inventory::query()->findOrFail($inventoryId)->update([
                        'is_stored_in_inventory_records' => 1
                    ]);
                }
            }


            DB::commit(); // Commit transaction
            session()->flash('success', trans('pharmacy.created'));
            return redirect()->route('pharmacy.inventory-records.index');
        }catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }
    }


    public function edit($inventoryRecordId)
    {
        $data['inventoryRecord'] = InventoryRecord::query()
                                                  ->with('getInventories')
                                                  ->where('id', '=', $inventoryRecordId)
                                                  ->first();

        $data['drugs']  = Drugs::query()
                               ->select('id', 'name_ar', 'name_en', 'parent_id')
                               ->whereNotNull('parent_id')->get();

        $data['stores'] = Store::query()->select('id', 'name')->get();

        if(!isset($data['inventoryRecord'])){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }


        return view('pharmacy.inventory_records.edit', $data);

    }

    public function update($inventoryRecordId,InventoryRecordRequest $request)
    {
        try {
            DB::beginTransaction(); // Start transaction

            $inventoryRecord = InventoryRecord::query()->find($inventoryRecordId);

            $inventoryRecord->update([
                'note'        => $request->note,
                'code_number' => $request->code_number ?? null,
                'date_time'   => now(),
                'created_by'  => auth()->user()->id,
                'clinic_id'   => auth()->user()->parent_id,
                'pharmacy_id' => auth()->user()->id,
            ]);

            if($request->inventory_id){
                foreach ($request->inventory_id as $index => $inventoryId){
                    InventoryRecordItem::query()->updateOrCreate(['id' => $request->inventory_record_item_id[$index]],[
                        'inventory_record_id' => $inventoryRecord->id,
                        'inventory_id' => $inventoryId,
                    ]);

                }
            }


            DB::commit(); // Commit transaction
            session()->flash('success', trans('pharmacy.updated'));
            return redirect()->route('pharmacy.inventory-records.index');
        }catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }
    }


    public function delete($inventoryRecordId)
    {
        $inventoryRecord = InventoryRecord::query()->findOrFail($inventoryRecordId);

        if(!isset($inventoryRecord)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $inventoryRecord->delete();

        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }


    public function search(Request $request)
    {
        $clinicId    = auth()->user()->parent_id;
        $searchQuery = $request->query('query');

        $data['inventoryRecords'] = InventoryRecord::query()
                                           ->select(
                                               'inventory_records.id',
                                               'inventory_records.created_by',
                                               'inventory_records.code_number',
                                               'inventory_records.created_at',
                                               'clinics.name as clinic_name',
                                           )
                                            ->leftJoin('clinics', 'clinics.id', '=', 'inventory_records.created_by')
                                            ->where(function ($query) use ($searchQuery) {
                                                if (!empty($searchQuery)) {
                                                    $query->where(function ($que) use ($searchQuery) {
                                                        $que->where('inventory_records.code_number', 'like', '%' . $searchQuery . '%')
                                                            ->orWhere('inventory_records.created_at', 'like', '%' . $searchQuery . '%')
                                                            ->orWhere('clinics.name', 'like', '%' . $searchQuery . '%');
                                                    });
                                                }
                                            })
                                            ->orWhere('inventory_records.clinic_id',$clinicId)
                                           ->get();
        return view('pharmacy.inventory_records.search', $data);
    }


}
