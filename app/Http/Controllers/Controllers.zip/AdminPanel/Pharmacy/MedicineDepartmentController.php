<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\MedicineDepartmentRequest;
use App\Models\DrugClinicTax;
use App\Models\Drugs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class MedicineDepartmentController extends Controller
{
    public function index()
    {
        $clinicId = auth()->user()->parent_id;

         $drugsDepartment = Drugs::query()
            ->with(['sections'])
            ->select('drugs.id', 'drugs.name_ar', 'drugs.name_en', 'drug_clinics_taxes.tax','drugs.updated_at', 'drugs.created_at','drugs.status')
            ->leftJoin('drug_clinics_taxes', 'drugs.id', '=', 'drug_clinics_taxes.drug_id')
            ->where(function ($query) use ($clinicId) {
                $query->whereNull('drugs.parent_id')
                      ->orWhere(function ($query) use ($clinicId) {
                          $query->where('drugs.clinic_id', $clinicId)
                                ->whereNull('drugs.parent_id')
                          ;
                      })
                ;
            })
            ->orderBy('drugs.id','DESC')
            ->get();



        return view('pharmacy.medicines_departments.index', compact('drugsDepartment'));
    }

    public function store(MedicineDepartmentRequest $request)
    {

        try{
            DB::beginTransaction(); // Start transaction

            $drug = Drugs::query()->create([
                'name_ar'     => $request->name_ar,
                'name_en'     => $request->name_en,
                'status'     => $request->status,
                'type'        => auth()->user()->app_type == 5 ? 'pharmacy' : 'admin',
                'clinic_id'   => auth()->user()->app_type == 5 ? auth()->user()->parent_id : '',
                'pharmacy_id' => auth()->user()->app_type == 5 ? auth()->user()->id : '',
            ]);

            if(auth()->user()->app_type == 5)
            {
                DrugClinicTax::query()->create([
                    'clinic_id'   => auth()->user()->parent_id,
                    'pharmacy_id' => auth()->user()->id,
                    'drug_id'     => $drug->id,
                    'tax'         => $request->tax,
                ]);
            }
            DB::commit(); // Commit transaction


            session()->flash('success', trans('pharmacy.created'));
            return redirect()->back();
        }
        catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }

    }

    public function update(MedicineDepartmentRequest $request, $drugId)
    {

        try {

            $drug = Drugs::query()->findOrFail($drugId);

            if (!isset($drug)) {
                session()->flash('error', trans('pharmacy.not_found'));
                return redirect()->back();
            }

            DB::beginTransaction(); // Start transaction

            $drug->update([
                'name_ar'     => $request->name_ar,
                'name_en'     => $request->name_en,
                'status'     => $request->status,
                'type'        => auth()->user()->app_type == 5 ? 'pharmacy' : 'admin',
                'clinic_id'   => auth()->user()->app_type == 5 ? auth()->user()->parent_id : '',
                'pharmacy_id' => auth()->user()->app_type == 5 ? auth()->user()->id : '',
            ]);

            if(auth()->user()->app_type == 5)
            {
                if ($drug->tax) {
                    $drug->tax->update([
                        'tax'         => $request->tax,
                        'clinic_id'   => auth()->user()->parent_id,
                        'pharmacy_id' => auth()->user()->id,
                    ]);
                }
                else {
                    DrugClinicTax::query()->create([
                        'clinic_id'   => auth()->user()->parent_id,
                        'pharmacy_id' => auth()->user()->id,
                        'drug_id'     => $drug->id,
                        'tax'         => $request->tax,
                    ]);
                }
            }

            DB::commit(); // Commit transaction


            session()->flash('success', trans('pharmacy.updated'));
            return redirect()->back();
        }
        catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs

            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }
    }


    public function delete($medicineDepartmentId)
    {
        $medicineDepartment = Drugs::query()->findOrFail($medicineDepartmentId);

        if (!isset($medicineDepartment)) {
            session()->flash('not_fount', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        if (auth()->user()->app_type == 5 && $medicineDepartment->type == 'admin')
        {
            session()->flash('error', trans('pharmacy.can_not_delete_pharmacy'));
            return redirect()->back();
        }


        if(isset($medicineDepartment->tax))
        {
            $medicineDepartment->tax->delete();
        }

        $medicineDepartment->delete();
        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }


    public function search(Request $request)
    {
        $clinicId    = auth()->user()->parent_id;
        $searchQuery = $request->query('query');

        $drugsDepartment = Drugs::query()
            ->with(['sections'])
            ->select('drugs.id', 'drugs.name_ar', 'drugs.name_en', 'drug_clinics_taxes.tax')
            ->leftJoin('drug_clinics_taxes', 'drugs.id', '=', 'drug_clinics_taxes.drug_id')
            ->where(function ($query) use ($searchQuery) {
                if (!empty($searchQuery)) {
                    $query->where(function ($que) use ($searchQuery) {
                        $que->where('drugs.name_ar', 'like', '%' . $searchQuery . '%')
                            ->orWhere('drugs.name_en', 'like', '%' . $searchQuery . '%')
                        ;
                    });
                }
            })
            ->where(function ($query) use ($clinicId) {
                $query->whereNull('drugs.parent_id')
                      ->orWhere(function ($query) use ($clinicId) {
                          $query->where('drugs.clinic_id', $clinicId)
                                ->whereNull('drugs.parent_id')
                          ;
                      })
                ;
            })
            ->get()
        ;

        return view('pharmacy.medicines_departments.search', compact('drugsDepartment'));
    }


}
