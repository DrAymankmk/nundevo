<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\CustomerRequest;
use App\Models\Customer;
use App\Models\ResponsiblePerson;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index()
    {
        $data['customers'] = Customer::query()
                                     ->select(
                                         'customers.id',
                                         'customers.name as customer_name',
                                         'customers.phone as customer_phone',
                                         'customers.representative_name as representative_name',
                                         'customers.representative_phone as representative_phone',
                                     )
                                     ->get();


        $data['responsiblePeople'] = ResponsiblePerson::query()->select('id', 'name')->get();
        return view('pharmacy.customers.index', $data);
    }

    public function store(CustomerRequest  $request)
    {
        Customer::query()->create([
            'name'                 => $request->name,
            'phone'                => $request->phone,
            'address'              => $request->address,
            'fax'                  => $request->fax,
            'email'                => $request->email,
            'website'              => $request->website,
            'representative_name'  => $request->representative_name,
            'representative_phone' => $request->representative_phone,
            'note'                 => $request->note,
            'clinic_id'            => auth()->user()->parent_id,
            'pharmacy_id'          => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.created'));
        return redirect()->back();
    }

    public function edit($customerId)
    {
        $data['customer'] = Customer::query()->findOrFail($customerId);
        if(!isset($data['customer'])){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }


        return response([
            'view' => view('pharmacy.customers.edit', $data)->render(),
        ]);
    }
    public function update(CustomerRequest $request, $customerId)
    {
        $customer = Customer::query()->findOrFail($customerId);
        if(!isset($customer)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }
        $customer->update([
            'name'                 => $request->name,
            'phone'                => $request->phone,
            'address'              => $request->address,
            'fax'                  => $request->fax,
            'email'                => $request->email,
            'website'              => $request->website,
            'representative_name'  => $request->representative_name,
            'representative_phone' => $request->representative_phone,
            'note'                 => $request->note,
            'clinic_id'            => auth()->user()->parent_id,
            'pharmacy_id'          => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.updated'));
        return redirect()->back();
    }

    public function delete($customerId)
    {
        $customer = Customer::query()->findOrFail($customerId);
        if(!isset($customer)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $customer->delete();

        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $clinicId = auth()->user()->parent_id;

        $searchQuery = $request->query('query');

        $data['customers'] = Customer::query()
                                     ->select(
                                         'customers.id',
                                         'customers.name as customer_name',
                                         'customers.phone as customer_phone',
                                         'customers.representative_name as representative_name',
                                         'customers.representative_phone as representative_phone',
                                     )
                                    ->where('customers.clinic_id', $clinicId)
                                     ->where(function ($query) use ($searchQuery) {
                                        if (!empty($searchQuery)) {
                                            $query->where(function ($que) use ($searchQuery) {
                                                $que->where('customers.name', 'like', '%' . $searchQuery . '%')
                                                    ->orWhere('customers.phone', 'like', '%' . $searchQuery . '%')
                                                    ->orWhere('customers.representative_phone', 'like', '%' . $searchQuery . '%')
                                                    ->orWhere('customers.representative_name', 'like', '%' . $searchQuery . '%');
                                            });
                                        }
                                    })->get();

        return view('pharmacy.customers.search', $data);

    }
}
