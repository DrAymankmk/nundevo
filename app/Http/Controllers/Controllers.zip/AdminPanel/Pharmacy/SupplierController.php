<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\SupplierRequest;
use App\Models\Supplier;
use Illuminate\Http\Request;

class SupplierController extends Controller
{
    public function index()
    {
        $suppliers = Supplier::query()->select('*')->orderBy('id','DESC')->get();
        return view('pharmacy.suppliers.index', compact('suppliers'));
    }

    public function store(SupplierRequest  $request)
    {
        Supplier::query()->create([
            'name'                 => $request->name,
            'phone'                => $request->phone,
            'address'              => $request->address,
            'fax'                  => $request->fax,
            'email'                => $request->email,
            'website'              => $request->website,
            'representative_name'  => $request->representative_name,
            'representative_phone' => $request->representative_phone,
            'tax_id_number'        => $request->tax_id_number,
            'note'                 => $request->note,
            'clinic_id'            => auth()->user()->parent_id,
            'pharmacy_id'          => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.created'));
        return redirect()->back();
    }

    public function edit($supplierId)
    {
        $data['supplier'] = Supplier::query()->findOrFail($supplierId);

        if(!isset($data['supplier'])){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }


        return response([
            'view' => view('pharmacy.suppliers.edit', $data)->render(),
        ]);
    }

    public function update(SupplierRequest $request, $supplierId)
    {
        $supplier = Supplier::query()->findOrFail($supplierId);
        if(!isset($supplier)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }
        $supplier->update([
            'name'                 => $request->name,
            'phone'                => $request->phone,
            'address'              => $request->address,
            'fax'                  => $request->fax,
            'email'                => $request->email,
            'website'              => $request->website,
            'representative_name'  => $request->representative_name,
            'representative_phone' => $request->representative_phone,
            'tax_id_number'        => $request->tax_id_number,
            'note'                 => $request->note,
            'clinic_id'            => auth()->user()->parent_id,
            'pharmacy_id'          => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.updated'));
        return redirect()->back();
    }

    public function delete($supplierId)
    {
        $supplier = Supplier::query()->findOrFail($supplierId);
        if(!isset($supplier)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }



        $supplier->delete();
        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $clinicId = auth()->user()->parent_id;

        $searchQuery = $request->query('query');

        $data['suppliers'] = Supplier::query()
                                     ->select('*')
                                     ->where('suppliers.clinic_id', $clinicId)
                                     ->where(function ($query) use ($searchQuery) {
                                         if (!empty($searchQuery)) {
                                             $query->where(function ($que) use ($searchQuery) {
                                                 $que->where('suppliers.name', 'like', '%' . $searchQuery . '%')
                                                     ->orWhere('suppliers.phone', 'like', '%' . $searchQuery . '%')
                                                     ->orWhere('suppliers.representative_phone', 'like', '%' . $searchQuery . '%')
                                                     ->orWhere('suppliers.representative_name', 'like', '%' . $searchQuery . '%');
                                             });
                                         }
                                     })->get();

        return view('pharmacy.suppliers.search', $data);

    }

}
