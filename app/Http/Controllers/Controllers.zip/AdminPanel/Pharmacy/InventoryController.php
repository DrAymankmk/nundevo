<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\InventoryRequest;
use App\Models\Drugs;
use App\Models\Inventory;
use App\Models\Store;
use Illuminate\Http\Request;

class InventoryController extends Controller
{
    public function index()
    {
        $data['drugs'] = Drugs::query()
                              ->select('id','name_ar','name_en','parent_id')
                              ->whereNotNull('parent_id')->get();
        $data['stores'] = Store::query()->select('id','name')->get();

         $data['inventories'] = Inventory::query()
            ->select(
                'inventories.id',
                'inventories.date as date_inventory',
                'inventories.quantity as actual_quantity',
                'drugs.name_ar as drug_name_ar',
                'drugs.name_en as drug_name_en',
                'drugs.short_code as code',
                'drug_sections.content_of_grand_unit as quantity_in_system',
                'drug_sections.price_of_grand_unit',
                'stores.name as store_name',
                'item_units.name as unit_name',
            )
            ->leftJoin('drugs','inventories.drug_id','=','drugs.id')
            ->leftJoin('stores','inventories.store_id','=','stores.id')
            ->leftJoin('drug_sections','inventories.drug_id','=','drug_sections.drug_id')
            ->leftJoin('item_units','drug_sections.grand_unit_id','=','item_units.id')
             ->where('is_stored_in_inventory_records','=',0)
            ->get();
        return view('pharmacy.inventory.index', $data);

    }

    public function store(InventoryRequest $request)
    {

        Inventory::query()->create([
            'store_id'    => $request->store_id,
            'drug_id'     => $request->drug_id,
            'quantity'    => $request->quantity,
            'date'        => $request->date,
            'clinic_id'   => auth()->user()->parent_id,
            'pharmacy_id' => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.created'));
        return redirect()->back();
    }

    public function edit($inventoryId)
    {
        $data['inventory'] = Inventory::query()->findOrFail($inventoryId);

        if(!isset($data['inventory'])){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }
        $data['stores']    = Store::query()->select('id', 'name')->get();
        $data['drugs']     = Drugs::query()->select('id', 'name_ar', 'name_en', 'parent_id')->whereNotNull('parent_id')->get();


        return response([
            'view' => view('pharmacy.inventory.edit', $data)->render()
        ]);
    }

    public function update(InventoryRequest $request,$inventoryId)
    {
        $inventory = Inventory::query()->findOrFail($inventoryId);

        if(!isset($inventory)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }
        $inventory->update([
            'store_id'    => $request->store_id,
            'drug_id'     => $request->drug_id,
            'quantity'    => $request->quantity,
            'date'        => $request->date,
            'clinic_id'   => auth()->user()->parent_id,
            'pharmacy_id' => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.updated'));
        return redirect()->back();
    }

    public function delete($inventoryId)
    {
        $inventory = Inventory::query()->findOrFail($inventoryId);

        if(!isset($inventory)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $inventory->delete();

        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }

    public function getItemsNotHaveInventor()
    {
        return view('pharmacy.inventory.items_not_have_inventory');

    }

    public function dataItemsNotHaveInventor(Request  $request)
    {
        $clinicId = auth()->user()->parent_id;
        $inventoryStartDate = date('Y-m-d', strtotime(str_replace('/','-',$request->inventory_start_date)));

        $drugIds = Inventory::query()
                            ->select('drug_id')
                            ->where('clinic_id',$clinicId)
                            ->where('date','>=', $inventoryStartDate)
                            ->get()->pluck('drug_id')->toArray();

        $data['drugs'] = Drugs::query()
                              ->select(
                                  'drugs.id',
                                  'drugs.name_en as drug_name_en',
                                  'drugs.name_ar as drug_name_ar',
                                  'drugs.international_barcode as international_barcode',
                                  'sections.name_ar as section_name_ar',
                                  'sections.name_en as section_name_en',
                                  'drug_sections.content_of_grand_unit',
                                  'drug_sections.price_of_grand_unit',
                              )
                              ->leftJoin('drugs as sections','drugs.parent_id','=','sections.id')
                              ->leftJoin('drug_sections','drug_sections.drug_id','=','drugs.id')
                              ->whereNotNull('drugs.parent_id')
                              ->whereNotIn('drugs.id',$drugIds)
                              ->orderBy('drugs.id', 'DESC')
                              ->groupBy('drugs.id')
                              ->get();

        return view('pharmacy.inventory.data_not_have_inventory', $data);
    }
    public function search(Request $request)
    {
        $clinicId                  = auth()->user()->parent_id;
        $searchQuery               = $request->query('query');
        $isStoredInInventoryRecord = $request->query('is_stored_in_inventory_records');


        $data['inventories'] = Inventory::query()
                                        ->select(
                                            'inventories.id',
                                            'inventories.date as date_inventory',
                                            'inventories.quantity as actual_quantity',
                                            'drugs.name_ar as drug_name_ar',
                                            'drugs.name_en as drug_name_en',
                                            'drugs.short_code as code',
                                            'drug_sections.content_of_grand_unit as quantity_in_system',
                                            'drug_sections.price_of_grand_unit',
                                            'stores.name as store_name',
                                            'item_units.name as unit_name',
                                        )
                                        ->leftJoin('drugs', 'inventories.drug_id', '=', 'drugs.id')
                                        ->leftJoin('stores', 'inventories.store_id', '=', 'stores.id')
                                        ->leftJoin('drug_sections', 'inventories.drug_id', '=', 'drug_sections.drug_id')
                                        ->leftJoin('item_units', 'drug_sections.grand_unit_id', '=', 'item_units.id')
                                        ->where('is_stored_in_inventory_records', '=', $isStoredInInventoryRecord)
                                        ->where(function ($query) use ($searchQuery) {
                                            if (!empty($searchQuery)) {
                                                $query->where(function ($que) use ($searchQuery) {
                                                    $que->where('inventories.date', 'like', '%' . $searchQuery . '%')
                                                        ->orWhere('drugs.name_ar', 'like', '%' . $searchQuery . '%')
                                                        ->orWhere('drugs.name_en', 'like', '%' . $searchQuery . '%')
                                                        ->orWhere('drugs.short_code', 'like', '%' . $searchQuery . '%')
                                                        ->orWhere('drug_sections.price_of_grand_unit', 'like', '%' . $searchQuery . '%')
                                                        ->orWhere('stores.name', 'like', '%' . $searchQuery . '%')
                                                        ->orWhere('item_units.name', 'like', '%' . $searchQuery . '%');
                                            });
                                            }
                                        })
                                        ->Where('inventories.clinic_id', $clinicId)
                                        ->get();
        return view('pharmacy.inventory.search', $data);
    }

}
