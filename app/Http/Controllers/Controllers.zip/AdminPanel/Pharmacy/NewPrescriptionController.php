<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Models\ClinicPoint;
use App\Models\ClinicSpecialist;
use App\Models\PatientMedicalReport;
use App\Models\ReservationDrug;
use App\Models\Reservations;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NewPrescriptionController extends Controller
{
    // new prescription
    function new_prescription(Request $request)
    {
        $id = Auth::user()->id;
        $query = ReservationDrug::groupBy('reservation_id')->latest()->where('status', 0);
        if ($request->q) {
            $users = User::where('ID_Number', $request->q)->orwhere('phone', $request->q)->pluck('id');
            $query->whereIn('user_id', $users);
        }
        $data['new_prescription'] = $query->paginate();
        return view('pharmacy.new_prescription.index', compact('data'));
    }

    // diagnosis_display
    function diagnosis_display($reservation_id)
    {
//        $diagnosis_ids = ReservationDrug::where('id',$id)->pluck('reservation_id');
        $diagnosis_display = ReservationDrug::where('reservation_id', $reservation_id)->groupBy('reservation_id')->get();
        $reservation = Reservations::with('reservation_drugs')->whereId($reservation_id)->first();
        $check_Reservation_drug = ReservationDrug::where('reservation_id', $reservation_id)->where('status',1)->exists();
        $lang = app()->getLocale() ?? 'en';
        return view('pharmacy.new_prescription.diagnosis_display', compact('diagnosis_display','check_Reservation_drug', 'reservation', 'lang'));
    }

    // add_drug_pharmacy
    function add_drug_pharmacy($reservation_id, Request $request)
    {

        $data = $request->all();
        $i = 0;
        $statusDrugs = $request->input('status_drug', []);

        foreach ($request->drug_ids as $key => $drug) {

            $currentStatus = isset($statusDrugs[$key]) ? $statusDrugs[$key] : 0; // Use 0 as a default value
            if ($currentStatus == "on") {
                $status = 1;
            } else {
                $status = 0;
            }
            $add_medicine = ReservationDrug::updateOrCreate(
                [
                    'id' => $drug,
                    'reservation_id' => $reservation_id,
                ],
                [
                    'status' => $status,
                ]
            );
        }
        if ($add_medicine) {

            $data = $request->all();
            $data['clinic_id'] = auth()->user()->id;
            $data['content_ar'] = 'تم صرف دواء جديد للمريض';
            $data['content_en'] = 'A new medication was dispensed to the patient';
            $data['point'] = 5;
            $create_point = ClinicPoint::create($data);
            session()->flash('success', trans('messages.Added'));
        }
        return redirect()->back();
    }
}
