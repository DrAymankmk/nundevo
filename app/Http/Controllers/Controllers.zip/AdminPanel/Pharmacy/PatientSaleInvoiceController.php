<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\PatientSaleInvoiceRequest;
use App\Http\Requests\Admin\Pharmacy\PurchaseInvoiceRequest;
use App\Http\Requests\Admin\Pharmacy\SaleInvoiceRequest;
use App\Models\AccountsTree;
use App\Models\Clinic;
use App\Models\Customer;
use App\Models\Drugs;
use App\Models\PatientSaleInvoice;
use App\Models\PatientSaleInvoiceItem;
use App\Models\PharmacyInvoice;
use App\Models\PharmacyInvoiceItem;
use App\Models\ReservationDrug;
use App\Models\SaleInvoice;
use App\Models\Store;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PatientSaleInvoiceController extends Controller
{

    public function index()
    {
        $clinicId = auth()->user()->parent_id;
        $data['patientSaleInvoices'] = PharmacyInvoice::query()
                                           ->select(
                                               'pharmacy_invoices.id',
                                               'pharmacy_invoices.is_saved_invoice',
                                               'pharmacy_invoices.invoice_number',
                                               'pharmacy_invoices.movement_type',
                                               'pharmacy_invoices.total_amount',
                                               'pharmacy_invoices.paid_value',
                                               'pharmacy_invoices.invoice_type',
                                               'users.name as user_name',
                                               'pharmacy_invoices.count_items_in_invoice as items_count',
                                               DB::raw("DATE_FORMAT(pharmacy_invoices.date, '%Y-%m-%d') as date"),
                                           )
                                           ->where('pharmacy_invoices.clinic_id', $clinicId)
                                           ->where('pharmacy_invoices.invoice_type','=','patient_sales')
                                           ->join('users', 'pharmacy_invoices.patient_id', '=', 'users.id')
                                           ->groupBy('pharmacy_invoices.id')
                                           ->get();
        return view('pharmacy.patient_sale_invoices.index', $data);
    }

    public function create()
    {
        $clinicId          = auth()->user()->parent_id;
        $data['drugs']    = Drugs::query()
                                 ->select('id', 'name_ar','name_en','parent_id')
                                 ->whereNotNull('parent_id')->get();

        $data['doctors']    = Clinic::query()
                                ->where('app_type','=',3)
                                ->select('id', 'name')->get();

        $data['users']    = User::query()
                                        ->select('id', 'name')->get();

        $data['accountTrees']    = AccountsTree::query()
                                               ->where('clinic_id', '=', $clinicId)
                                               ->select('id', 'name_ar','name_en')->get();


        $data['stores'] = Store::query()
                               ->where('clinic_id', '=', $clinicId)
                               ->select('id', 'name')->get();

        return view('pharmacy.patient_sale_invoices.create',$data);
    }

    public function store(PatientSaleInvoiceRequest $request)
    {

        try {

            DB::beginTransaction(); // Start transaction

            $saleInvoice = PharmacyInvoice::storeInvoice($request);

            $discount              = [];
            $netTotal              = [];
            $netTotalAfterDiscount = [];
            $taxValue              = [];
            $totalAmount           = [];


            if($request->drug_id){
                foreach ($request->drug_id as $index => $drugId){

                    $quantity           = floatval($request->quantity[$index]);
                    $price              = floatval($request->price[$index]);
                    $percentageDiscount = floatval($request->percentage_discount[$index]) ?? 0;
                    $valueDiscount      = floatval($request->value_discount[$index]) ?? 0;
                    $discount[$index]   = ($quantity * $price * $percentageDiscount / 100) + $valueDiscount;

                    $netTotal[$index]              = $quantity * $price;
                    $netTotalAfterDiscount[$index] = $netTotal[$index] - $discount[$index];
                    $taxValue[$index]              = ($netTotal[$index] - $discount[$index]) * floatval($request->tax[$index]) / 100;
                    $totalAmount[$index]           = ($netTotal[$index] - $discount[$index]) + $taxValue[$index];

                    if($request->quantity[$index] != ''){
                        PharmacyInvoiceItem::storeInvoiceItem($request, $saleInvoice->id, $index, $netTotal[$index], $netTotalAfterDiscount[$index], $taxValue[$index], $totalAmount[$index]);
                    }
                }

                $saleInvoice->net_total                = array_sum($netTotal);
                $saleInvoice->net_total_after_discount = array_sum($netTotalAfterDiscount);
                $saleInvoice->tax_value                = array_sum($taxValue);
                $saleInvoice->total_amount             = array_sum($totalAmount);

                $saleInvoice->save();
            }


            DB::commit(); // Commit transaction
            session()->flash('success', trans('pharmacy.created'));
            return redirect()->route('pharmacy.patient-sale-invoice.index');


        }
        catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }
    }
    public function edit($patientSaleInvoiceId)
    {
        $data['patientSaleInvoice'] = PharmacyInvoice::query()->findOrFail($patientSaleInvoiceId);
        if(!isset($data['patientSaleInvoice'])){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $clinicId          = auth()->user()->parent_id;
        $data['drugs']    = Drugs::query()
                                 ->select('id', 'name_ar','name_en','parent_id')
                                 ->whereNotNull('parent_id')->get();

        $data['doctors']    = Clinic::query()
                                    ->where('app_type','=',3)
                                    ->select('id', 'name')->get();

        $data['users']    = User::query()
                                ->select('id', 'name')->get();

        $data['accountTrees']    = AccountsTree::query()
                                               ->where('clinic_id', '=', $clinicId)
                                               ->select('id', 'name_ar','name_en')->get();


        $data['stores'] = Store::query()
                               ->where('clinic_id', '=', $clinicId)
                               ->select('id', 'name')->get();


        return view('pharmacy.patient_sale_invoices.edit',$data);

    }

    public function update(PatientSaleInvoiceRequest $request, $pharmacyInvoiceId)
    {
        try {
            $pharmacyInvoice = PharmacyInvoice::query()->findOrFail($pharmacyInvoiceId);

            if(!isset($pharmacyInvoice)){
                session()->flash('error', trans('pharmacy.not_found'));
                return redirect()->back();
            }

            DB::beginTransaction(); // Start transaction


            PharmacyInvoice::updateInvoice($request);


            $discount              = [];
            $netTotal              = [];
            $netTotalAfterDiscount = [];
            $taxValue              = [];
            $totalAmount           = [];

            if($request->drug_id){
                foreach ($request->drug_id as $index => $drugId){


                    $quantity           = floatval($request->quantity[$index]);
                    $price              = floatval($request->price[$index]);
                    $percentageDiscount = floatval($request->percentage_discount[$index]) ?? 0;
                    $valueDiscount      = floatval($request->value_discount[$index]) ?? 0;
                    $discount[$index]   = ($quantity * $price * $percentageDiscount / 100) + $valueDiscount;

                    $netTotal[$index]              = $quantity * $price;
                    $netTotalAfterDiscount[$index] = $netTotal[$index] - $discount[$index];
                    $taxValue[$index]              = ($netTotal[$index] - $discount[$index]) * floatval($request->tax[$index]) / 100;
                    $totalAmount[$index]           = ($netTotal[$index] - $discount[$index]) + $taxValue[$index];
                    if($request->quantity[$index] != ''){
                        PharmacyInvoiceItem::updateInvoiceItem($request, $pharmacyInvoiceId, $index, $netTotal[$index], $netTotalAfterDiscount[$index], $taxValue[$index], $totalAmount[$index]);
                    }
                }

                $pharmacyInvoice->net_total                = array_sum($netTotal);
                $pharmacyInvoice->net_total_after_discount = array_sum($netTotalAfterDiscount);
                $pharmacyInvoice->tax_value                = array_sum($taxValue);
                $pharmacyInvoice->total_amount             = array_sum($totalAmount);

                $pharmacyInvoice->save();
            }
            DB::commit(); // Commit transaction
            session()->flash('success', trans('pharmacy.created'));
            return redirect()->route('pharmacy.patient-sale-invoice.index');

        }catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction if an exception occurs
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }





    }

    public function delete($patientSaleInvoiceId)
    {
        $patientSaleInvoice = PharmacyInvoice::query()->findOrFail($patientSaleInvoiceId);

        if(!isset($patientSaleInvoice)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $patientSaleInvoice->delete();
        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $clinicId = auth()->user()->parent_id;

        $searchQuery = $request->query('query');


        $data['patientSaleInvoices'] = PharmacyInvoice::query()
                                            ->select(
                                                'pharmacy_invoices.id',
                                                'pharmacy_invoices.is_saved_invoice',
                                                'pharmacy_invoices.invoice_number',
                                                'pharmacy_invoices.date',
                                                'pharmacy_invoices.total_amount',
                                                'pharmacy_invoices.paid_value',
                                                'pharmacy_invoices.invoice_type',
                                                'users.name as user_name',
                                                DB::raw('count(pharmacy_invoice_items.pharmacy_invoice_id) as items_count')
                                            )
                                            ->where('pharmacy_invoices.clinic_id', $clinicId)
                                            ->where('pharmacy_invoices.invoice_type','=','patient_sales')
                                            ->where(function ($query) use ($searchQuery) {
                                                if (!empty($searchQuery)) {
                                                    $query->where(function ($que) use ($searchQuery) {
                                                        $que->where('pharmacy_invoices.invoice_number', 'like', '%' . $searchQuery . '%')
                                                            ->orWhere('pharmacy_invoices.date', 'like', '%' . $searchQuery . '%')
                                                            ->orWhere('users.name', 'like', '%' . $searchQuery . '%');
                                                    });
                                                }
                                            })
                                            ->join('pharmacy_invoice_items', 'pharmacy_invoice_items.pharmacy_invoice_id', '=', 'pharmacy_invoices.id')
                                            ->join('users', 'pharmacy_invoices.patient_id', '=', 'users.id')
                                            ->groupBy('pharmacy_invoices.id')
                                            ->get();

        return view('pharmacy.patient_sale_invoices.search', $data);


    }

    public function getDrugsBelongsToPatient(Request $request)
    {
        $patientId = $request->patient_id;

        if($patientId == '')
            return  '';

        $data['drugs']    = Drugs::query()
                                 ->select('id', 'name_ar','name_en','parent_id')
                                 ->whereNotNull('parent_id')->get();


         $data['reservationDrugs'] = Drugs::query()
            ->select(
                'drugs.id as drug_id',
                'reservation_drugs.user_id as user_id',
                'pharmacy_invoices.store_id as store_id',
                'pharmacy_invoices.movement_type as movement_type',
                'pharmacy_invoice_items.barcode as barcode',
                'drug_clinics_taxes.tax',
                'drug_sections.price_of_grand_unit as price',
                DB::raw('SUM(CASE WHEN pharmacy_invoices.movement_type = "purchases" THEN pharmacy_invoice_items.quantity ELSE 0 END) as balance'),
            )
            ->leftJoin('reservation_drugs', 'reservation_drugs.drug_id', '=', 'drugs.id')
            ->leftJoin('drug_clinics_taxes', 'drug_clinics_taxes.drug_id', '=', 'drugs.parent_id')
            ->leftJoin('drug_sections', 'drug_sections.drug_id', '=', 'drugs.id')
            ->leftJoin('pharmacy_invoice_items', 'pharmacy_invoice_items.drug_id', '=', 'drugs.id')
            ->leftJoin('pharmacy_invoices', 'pharmacy_invoices.id', '=', 'pharmacy_invoice_items.pharmacy_invoice_id')
             ->where('pharmacy_invoices.store_id', '=', $request->store_id)
             ->where('reservation_drugs.user_id', '=', $patientId)
            ->where('pharmacy_invoice_items.barcode', '!=', null)
            ->where('pharmacy_invoices.movement_type', '=', 'purchases')
            ->groupBy('drugs.id')
            ->get();

        return view('pharmacy.patient_sale_invoices.get_drugs_by_patient',$data);
    }
}
