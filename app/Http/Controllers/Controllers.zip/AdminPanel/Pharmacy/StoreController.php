<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\StoreRequest;
use App\Models\Clinic;
use App\Models\ResponsiblePerson;
use App\Models\Store;
use Illuminate\Http\Request;

class StoreController extends Controller
{
    public function index()
    {
        $data['stores']             = Store::query()->select('*')->get();
        $data['responsiblePeople']  = Clinic::query()->where('app_type', '=', 27)->get();
//        $data['responsiblePeople'] = ResponsiblePerson::query()->select('id', 'name')->get();
        return view('pharmacy.stores.index', $data);
    }

    public function store(StoreRequest $request)
    {
        Store::query()->create([
            'name'                  => $request->name,
            'address'               => $request->address,
            'phone'                 => $request->phone,
            'responsible_person_id' => $request->responsible_person_id,
            'clinic_id'             => auth()->user()->parent_id,
            'pharmacy_id'           => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.created'));
        return redirect()->back();
    }

    public function edit($storeId)
    {
        $store = Store::query()->findOrFail($storeId);
        if(!isset($store)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

//        $responsiblePeople = ResponsiblePerson::query()->select('id', 'name')->get();
        $responsiblePeople = Clinic::query()->where('app_type', '=', 27)->get();

        return response([
            'view' => view('pharmacy.stores.edit', compact('store','responsiblePeople'))->render(),
        ]);
    }

    public function update($storeId, StoreRequest $request)
    {
        $store = Store::query()->findOrFail($storeId);
        if(!isset($store)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $store->update([
            'name'                  => $request->name,
            'address'               => $request->address,
            'phone'                 => $request->phone,
            'responsible_person_id' => $request->responsible_person_id,
            'clinic_id'             => auth()->user()->parent_id,
            'pharmacy_id'           => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.updated'));
        return redirect()->back();
    }

    public function delete($storeId)
    {
        $store = Store::query()->findOrFail($storeId);
        if(!isset($store)){
            session()->flash('error', trans('pharmacy.not_found'));
            return redirect()->back();
        }

        $store->delete();

        session()->flash('success', trans('pharmacy.deleted'));
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $clinicId = auth()->user()->parent_id;

        $searchQuery = $request->query('query');

        $data['stores'] = Store::query()
                                     ->select('*')
                                     ->where('clinic_id', $clinicId)
                                     ->where(function ($query) use ($searchQuery) {
                                         if (!empty($searchQuery)) {
                                             $query->where(function ($que) use ($searchQuery) {
                                                 $que->where('name', 'like', '%' . $searchQuery . '%')
                                                     ->orWhere('phone', 'like', '%' . $searchQuery . '%')
                                                     ->orWhere('address', 'like', '%' . $searchQuery . '%');
                                             });
                                         }
                                     })->get();

        return view('pharmacy.stores.search', $data);

    }


}
