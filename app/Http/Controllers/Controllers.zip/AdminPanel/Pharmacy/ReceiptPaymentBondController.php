<?php

namespace App\Http\Controllers\AdminPanel\Pharmacy;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Pharmacy\ReceiptPaymentBondRequest;
use App\Models\AccountsTree;
use App\Models\Bonds;
use Illuminate\Http\Request;

class ReceiptPaymentBondController extends Controller
{
    public function index()
    {
        $data['bonds'] = Bonds::query()
                              ->select(
                                  'bonds.id as bond_id',
                                  'bonds.movement_type as movement_type',
                                  'bonds.payment_method as payment_method',
                                  'bonds.price as price',
                                  'accounts_trees.name_ar as name_ar',
                                  'accounts_trees.name_en as name_en',
                                  'bonds.date',
                              )
                              ->leftJoin('accounts_trees', 'accounts_trees.id', '=', 'bonds.account_id')
                              ->orderBy('bonds.date', 'desc')
                              ->get();

        $data['accounts'] = AccountsTree::query()->select('id','name_ar','name_en')->get();
        return view('pharmacy.bonds.index',$data);
    }

    public function store(ReceiptPaymentBondRequest  $request)
    {
        Bonds::query()->create([
            'account_id'     => $request->account_id ?? 1,
            'movement_type'  => $request->movement_type,
            'price'          => $request->price,
            'payment_method' => $request->payment_method,
            'date'           => date('Y-m-d', strtotime(str_replace('/','-',$request->date))),
            'user_id'        => auth()->user()->id,
        ]);

        session()->flash('success', trans('pharmacy.created'));
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $clinicId = auth()->user()->parent_id;

        $searchQuery = $request->query('query');

        $data['bonds'] = Bonds::query()
                              ->select(
                                  'bonds.id as bond_id',
                                  'bonds.movement_type as movement_type',
                                  'bonds.payment_method as payment_method',
                                  'bonds.price as price',
                                  'accounts_trees.name_ar as name_ar',
                                  'accounts_trees.name_en as name_en',
                                  'bonds.date',
                              )
                              ->leftJoin('accounts_trees', 'accounts_trees.id', '=', 'bonds.account_id')
                              ->where('clinic_id', $clinicId)
                              ->where(function ($query) use ($searchQuery) {
                                    if (!empty($searchQuery)) {
                                        $query->where(function ($que) use ($searchQuery) {
                                            $que->Where('bonds.price', 'like', '%' . $searchQuery . '%')
                                                ->orWhere('bonds.date', 'like', '%' . $searchQuery . '%')
                                                ->orWhere('accounts_trees.name_ar', 'like', '%' . $searchQuery . '%')
                                                ->orWhere('accounts_trees.name_en', 'like', '%' . $searchQuery . '%');
                                        });
                                    }
                              })->get();

        return view('pharmacy.bonds.search', $data);

    }

}
