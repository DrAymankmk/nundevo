<?php

namespace App\Http\Controllers\AdminPanel\Insurance;

use App\Http\Controllers\Controller;
use App\Models\InsuranceCompanies;
use App\Models\Specialty;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    //  get report company
    function insured_invoices_reports($company_id, $type)
    {
        $specialist = [];
        if ($type == 1) {
            $title = trans('insurance.Business_companies');
            $blade = 'insured_invoices_reports';
        } else {
            $title = trans('insurance.Insurance_companies');
            $blade = 'services_reports';
            $specialist = Specialty::where('status',1)->latest()->get();
        }
        $company = InsuranceCompanies::where('id', $company_id)->latest()->select('id', 'name_' . app()->getLocale() . ' as name', 'status', 'name_ar', 'name_en', 'phone', 'email', 'website', 'fax', 'code', 'provider_id','clinic_id')->first();
        return view('Insurances.reports.'.$blade, compact('company', 'title', 'type','specialist'));
    }
}
