<?php

namespace App\Http\Controllers\AdminPanel\Insurance;

use App\Http\Controllers\Controller;
use App\Models\ClinicServices;
use App\Models\ClinicSpecialist;
use App\Models\Drugs;
use App\Models\DrugSection;
use App\Models\InsuranceClasses;
use App\Models\InsuranceCompanies;
use App\Models\InsurancesCompaniesServices;
use App\Models\Service;
use Illuminate\Http\Request;

class ServicesDiscountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        if (empty($request->percentage_discount) && empty($request->fixed_discount)) {
            session()->flash('error', __(trans('insurance.choose_percentage_or_fixed_discount')));
            return redirect()->back();
        }

        if (!empty($request->fixed_discount)) {
            if ($request->type == 4) {
                $clinic_service = ClinicServices::where(['price_of_grand_unit' => $request->service_id, 'clinic_id' => auth()->user()->parent_id])->first();
                $service_price = $clinic_service->price_of_grand_unit ?? 0;
            } else {
                $clinic_service = ClinicServices::where(['service_id' => $request->service_id, 'clinic_id' => auth()->user()->parent_id])->first();
                $service_price = $clinic_service->price ?? 0;
            }

            if ($clinic_service) {
                if ($request->fixed_discount > $service_price) {
                    session()->flash('error', __(trans('insurance.must_price_larger_than_discount')));
                    return redirect()->back();
                }
            }
        }
        if (empty($request->id)) {
            $query = InsurancesCompaniesServices::where(['clinic_id' => auth()->user()->parent_id, 'company_id' => $request->company_id]);
            if ($request->type == 4) {
                $query->where('drug_section_id', $request->service_id);
            } else {
                $query->where('clinic_service_id', $request->service_id);
            }
            $check_service = $query->first();
            if ($check_service) {
                session()->flash('error', __(trans('insurance.already_exist')));
                return redirect()->back();
            }
        }

        $data['clinic_id'] = auth()->user()->parent_id;
        $data['insurance_id'] = auth()->user()->id;
        $data['class_id'] = $request->class_id ?? null;
        if ($request->type == 4) {
            $data['drug_section_id'] = $request->service_id;
        } else {
            $data['clinic_service_id'] = $request->service_id;
        }
        if (!empty($request->id)) {
            $message = trans('admin.updated');
        } else {
            $message = trans('admin.added');
        }
        $added = InsurancesCompaniesServices::updateOrCreate(
            [
                'id' => $request->id,
            ],
            $data
        );

        if ($added) {
            session()->flash('success', $message);
        }
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($company_id)
    {
        $company = InsuranceCompanies::whereId($company_id)->select('id', 'name_' . app()->getLocale() . ' as name', 'status', 'type')->first();
        return view('Insurances.services_discount', compact('company'));
    }

    public function services($company_id, $type = null)
    {
        $clinic_id = auth()->user()->parent_id;
        if ($type == 1) {
            $title = trans('insurance.labs_discount');
            $service_name = trans('admin.analysis');
        } elseif ($type == 2) {
            $title = trans('insurance.rays_discount');
            $service_name = trans('admin.rays');
        } elseif ($type == 3) {
            $title = trans('insurance.services_discount');
            $service_name = trans('admin.services');
        } else {
            $title = trans('insurance.drugs_discount');
            $service_name = trans('admin.doctor.Drug lists');
        }
        $company = InsuranceCompanies::whereId($company_id)->select('id', 'name_' . app()->getLocale() . ' as name', 'status', 'type')->first();
        if ($type == 1 || $type == 2) {
            $data['services'] = ClinicServices::where(['clinic_id' => $clinic_id, 'type' => $type])->where('status', 1)->orderBy('id', 'desc')->get();
        } elseif ($type == 4) {
            $data['categories'] = DrugSection::where('clinic_id', $clinic_id)->groupBy('category_id')->get();
        } else {
            $data['specializations'] = ClinicSpecialist::with('specialties')->where('clinic_id', $clinic_id)->where('type', 1)->where('status', 1)->get();
        }
        $data['type'] = $type;
        $data['service_name'] = $service_name;
        $data['classes'] = InsuranceClasses::where('clinic_id', auth()->user()->parent_id)->latest()->select('id', 'name_' . app()->getLocale() . ' as name', 'status', 'name_ar', 'name_en')->get();
        $data['clinic_service'] = InsurancesCompaniesServices::where(['type' => $type, 'company_id' => $company_id, 'clinic_id' => auth()->user()->parent_id])->orderBy('id', 'desc')->get();

//        $companies = InsuranceCompanies::where(['clinic_id'=>auth()->user()->parent_id,'type'=>$type])->latest()->select('id','name_'.app()->getLocale().' as name','status','name_ar','name_en','phone','email','website','fax','code','provider_id')->get();
        return view('Insurances.services_discount', compact('company', 'title', 'data'));
    }

    // get specialist
    function getSpecialties(Request $request)
    {
        if ($request->type == 4) {
            $services = DrugSection::with('drugs')->where(['clinic_id' => auth()->user()->parent_id, 'category_id' => $request->specialty_id])->orderBy('id', 'desc')->get();
        } else {
            $specialists = Service::where('specialty_id', $request->specialty_id)->pluck('id');
            $services = ClinicServices::with('services')->whereIn('service_id', $specialists)->where(['clinic_id' => auth()->user()->parent_id, 'type' => $request->type, 'status' => 1])->orderBy('id', 'desc')->get();
        }

        return response()->json($services);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($service_id)
    {
        InsurancesCompaniesServices::whereId($service_id)->delete();
        $message = trans('admin.deleted');
        return response()->json($message);
    }
}
