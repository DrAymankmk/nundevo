<?php

namespace App\Http\Controllers\AdminPanel\Insurance;

use App\Http\Controllers\Controller;
use App\Models\InsuranceClasses;
use App\Models\InsuranceCompanies;
use Illuminate\Http\Request;

class CompaniesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $new_company = new InsuranceCompanies();
        $data['clinic_id'] = auth()->user()->parent_id;
        $data['insurance_id'] = auth()->user()->id;
        $create_company = $new_company->create($data);
        if ($create_company) {
            session()->flash('success', __(trans('admin.added')));
        }
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($type)
    {
        if ($type == 1) {
            $title = trans('insurance.Business_companies');
        } else {
            $title = trans('insurance.Insurance_companies');
        }
        $companies = InsuranceCompanies::where(['clinic_id'=>auth()->user()->parent_id,'type'=>$type])->latest()->select('id','name_'.app()->getLocale().' as name','status','name_ar','name_en','phone','email','website','fax','code','provider_id')->get();
        return view('insurances.companies', compact('companies','title','type'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $data['insurance_id'] = auth()->user()->id;
        $edit_company = InsuranceCompanies::whereId($id)->first();
        $edit_company->update($data);
        session()->flash('success', __(trans('admin.updated')));
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        InsuranceCompanies::whereId($id)->delete();
        $message = trans('admin.deleted');
        return response()->json($message);
    }
}
