<?php

namespace App\Http\Controllers\AdminPanel\Insurance;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\AddDepartment;
use App\Models\InsuranceClasses;
use Illuminate\Http\Request;

class ClassesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $classes = InsuranceClasses::where('clinic_id',auth()->user()->parent_id)->latest()->select('id','name_'.app()->getLocale().' as name','status','name_ar','name_en')->get();
        return view('insurances.classes', compact('classes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddDepartment $request)
    {
        $data = $request->all();
        $new_class = new InsuranceClasses();
        $data['clinic_id'] = auth()->user()->parent_id;
        $data['insurance_id'] = auth()->user()->id;
        $create_class = $new_class->create($data);
        if ($create_class) {
            session()->flash('success', __(trans('admin.added')));
        }
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $data['insurance_id'] = auth()->user()->id;
        $edit_class = InsuranceClasses::whereId($id)->first();
        $edit_class->update($data);
        session()->flash('success', __(trans('admin.updated')));
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($insurance_id)
    {
        InsuranceClasses::whereId($insurance_id)->delete();
        $message = trans('admin.deleted');
        return response()->json($message);
    }
}
