<?php

namespace App\Http\Controllers\AdminPanel\Insurance;

use App\Http\Controllers\Controller;
use App\Models\InsurancePolicy;
use App\Models\InsurancesCompaniesServices;
use App\Models\PatientService;
use Illuminate\Http\Request;

class InsuranceApprovalsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
          $insurance_approvals = PatientService::where(['clinic_id'=>auth()->user()->parent_id,'confirm_insurance'=>0])->latest()->groupBy('doctor_id')->get();
        return view('insurances.insurance_approvals', compact('insurance_approvals'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $service = PatientService::whereId($id)->first();
        $approval_services = PatientService::with('services')->where(['user_id'=>$service->user_id,'doctor_id'=>$service->doctor_id])->latest()->get();
        $insurances_policy = InsurancePolicy::where(['company_id'=>$service->user->company_id ?? null,'class_id'=>$service->user->class_id ?? null,'clinic_id'=>$service->clinic_id])->first();

        return view('insurances.approval_services', compact('approval_services','insurances_policy','service'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
