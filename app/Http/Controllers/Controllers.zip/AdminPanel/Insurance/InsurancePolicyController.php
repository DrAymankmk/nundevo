<?php

namespace App\Http\Controllers\AdminPanel\Insurance;

use App\Http\Controllers\Controller;
use App\Models\InsuranceClasses;
use App\Models\InsuranceCompanies;
use App\Models\InsurancePolicy;
use Illuminate\Http\Request;

class InsurancePolicyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $classes = InsuranceClasses::where('clinic_id',auth()->user()->parent_id)->latest()->select('id','name_'.app()->getLocale().' as name','status','name_ar','name_en')->get();
        return view('insurances.classes', compact('classes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddDepartment $request)
    {
        $data = $request->all();
        $new_class = new InsuranceClasses();
        $data['clinic_id'] = auth()->user()->parent_id;
        $data['insurance_id'] = auth()->user()->id;
        $create_class = $new_class->create($data);
        if ($create_class) {
            session()->flash('success', __(trans('admin.added')));
        }
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $company = InsuranceCompanies::whereId($id)->latest()->select('id','name_'.app()->getLocale().' as name','type','insurance_company_id','claims_management_company','tax','policy_number','date_from','date_to')->first();
        $insurance_companies = InsuranceCompanies::where(['clinic_id'=>auth()->user()->parent_id,'type'=>2])->latest()->select('id','name_'.app()->getLocale().' as name','type')->get();
        $classes = InsuranceClasses::where('clinic_id',auth()->user()->parent_id)->latest()->select('id','name_'.app()->getLocale().' as name','status','name_ar','name_en')->get();
        $insurance_policy = InsurancePolicy::where(['clinic_id'=>auth()->user()->parent_id,'company_id'=>$id])->latest()->orderBy('id','desc')->get();
        return view('insurances.insurance_policy', compact('insurance_companies','company','classes','insurance_policy'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $company_id)
    {
        $data = $request->all();
        if (!empty($request->policy_id)) {
            $message = trans('admin.updated');
        } else {
            $message = trans('admin.added');
        }
        $data['clinic_id'] = auth()->user()->parent_id;
        $data['company_id'] = $company_id;
        if (!empty($request->policy_id)) {
            $added_or_update = InsurancePolicy::updateOrCreate(
                [
                    'id' => $request->policy_id,
                ],
                $data
            );
        } else {
            $added_or_update = InsurancePolicy::updateOrCreate(
                [
                    'clinic_id' => auth()->user()->parent_id,
                    'company_id' => $company_id,
                    'class_id' => $request->class_id,
                ],
                $data
            );
        }


        if ($added_or_update) {
            session()->flash('success', $message);
        }
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($insurance_id)
    {
        InsurancePolicy::whereId($insurance_id)->delete();
        $message = trans('admin.deleted');
        return response()->json($message);
    }
}
