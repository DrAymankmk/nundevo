<?php

namespace App\Http\Controllers\AdminPanel\FinancialAccounts;

use App\Http\Controllers\Controller;
use App\Models\AccountsTree;
use App\Models\CostCenters;
use App\Models\DailyEntry;
use App\Models\Restrictions;
use Illuminate\Http\Request;

class financialBondsController extends Controller
{
    // financial bonds
    function index()
    {
        $accounts = AccountsTree::where('account_type', 3)->get();
        $restrictions = Restrictions::where('clinic_id', auth()->user()->parent_id)->get();
        $cost_centers = CostCenters::where('clinic_id', auth()->user()->parent_id)->get();
        return view('financial_accounts.financial_bonds', compact('accounts', 'restrictions', 'cost_centers'));
    }

    // create_financial_bonds
    function create_financial_bonds(Request $request)
    {
        if (!empty($request->credit)) {
            $data = $request->all();
            $data['clinic_id'] = auth()->user()->parent_id;
            $data['account_id'] = auth()->user()->id;
            $data['type'] = $request->type;
            $create_daily = DailyEntry::create($data);
            $added = new Restrictions();
            $added->clinic_id = auth()->user()->parent_id;
            $added->account_id = auth()->user()->id;
            $added->credit = $request->credit;
            $added->debit = 0;
            $added->daily_entry_id = $create_daily->id;
            $added->final_accounts = $request->final_accounts;
            $added->process = 2;
            $added->notice = $request->notice;
            $added->payment_method = $request->payment_method;
            $added->cost_center_id = $request->cost_center_id;
            $added->save();
        }

        if (!empty($request->debit)) {
            $data = $request->all();
            $data['type'] = $request->type;
            $data['clinic_id'] = auth()->user()->parent_id;
            $data['account_id'] = auth()->user()->id;
            $create_daily = DailyEntry::create($data);
            $added = new Restrictions();
            $added->clinic_id = auth()->user()->parent_id;
            $added->account_id = auth()->user()->id;
            $added->credit = 0;
            $added->debit = $request->debit;
            $added->process = 3;
            $added->daily_entry_id = $create_daily->id;
            $added->final_accounts = $request->final_accounts;
            $added->notice = $request->notice;
            $added->tax = $request->tax;
            $added->payment_method = $request->payment_method;
            $added->cost_center_id = $request->cost_center_id;
            $added->save();
        }

        session()->flash('success', trans('admin.added'));
        return redirect()->back();

    }
}
