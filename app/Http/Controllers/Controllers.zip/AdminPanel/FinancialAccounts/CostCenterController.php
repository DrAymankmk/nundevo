<?php

namespace App\Http\Controllers\AdminPanel\FinancialAccounts;
use App\Http\Controllers\Controller;
use App\Models\AccountsTree;
use App\Models\CostCenters;
use Illuminate\Http\Request;

class CostCenterController extends Controller
{
    // cost center controller
    function index()
    {
        $cost_center = CostCenters::where('clinic_id', auth()->user()->parent_id)->get();
        return view('financial_accounts.cost_center', compact('cost_center'));
    }

    public function create_cost_center(Request $request)
    {
        $data = $request->all();
        $data['clinic_id'] = auth()->user()->parent_id;
        $data['account_id'] = auth()->user()->id;
        $create_cost_center = CostCenters::create($data);
        if ($create_cost_center) {
            session()->flash('success', __(trans('admin.added')));
        }
        return redirect()->back();
    }

    public function edit_cost_center($id, Request $request)
    {
        $data = $request->all();
        $edit_cost_center = CostCenters::where('id', $id)->first();
        $edit_cost_center->update($data);
        session()->flash('success', trans('admin.updated'));
        return redirect()->back();
    }

    function destroy_edit_cost_center($id)
    {
        CostCenters::where('id', $id)->delete();
        session()->flash('success', trans('messages.deleted'));
        return redirect()->back();
    }
}
