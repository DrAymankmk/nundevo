<?php

namespace App\Http\Controllers\AdminPanel\FinancialAccounts;

use App\Http\Controllers\Controller;
use App\Models\AccountsTree;
use Illuminate\Http\Request;

class AccountsController extends Controller
{
    function index($category_id)
    {
        $category = AccountsTree::with('partial', 'branch')->whereId($category_id)->first();
        $accounts_tree = AccountsTree::with('children')->where('parent_id', null)->get();
        return view('financial_accounts.index', compact('accounts_tree', 'category_id', 'category'));
    }

    public function create_account_category(Request $request, $category_id)
    {
//        $lastChild = AccountsTree::where('id', $category_id)->orderBy('id', 'desc')->first();
        $lastChild = AccountsTree::where('parent_id', $category_id)
            ->orderBy('code', 'desc')
            ->first();
        $parent = AccountsTree::findOrFail($category_id);

        $data = $request->all();
        $data['account_id'] = auth()->user()->id;
        $data['clinic_id'] = auth()->user()->parent_id;
        $data['account_type'] = $request->child_id ? 3 : 2;

        if ($lastChild) {
            $data['code'] = $lastChild->code + 1;
        } else {
            $data['code'] = $parent->code . '01';
        }
        $data['parent_id'] = $category_id;
        $create_department = AccountsTree::create($data);
        if ($create_department) {
            session()->flash('success', __(trans('admin.added')));
        }
        return redirect()->back();
    }

    public function edit_account_category($id, Request $request)
    {
        $data = $request->all();
        $edit_category = AccountsTree::where('id', $id)->first();
        $edit_category->update($data);
        session()->flash('success', trans('admin.updated'));
        return redirect()->back();
    }

    function destroy_account_category($id)
    {
        AccountsTree::where('id', $id)->delete();
        session()->flash('success', trans('messages.deleted'));
        return redirect()->back();
    }


    function category_report($category_id)
    {
        $category = AccountsTree::with('partial', 'branch')->whereId($category_id)->first();
        return view('financial_accounts.report', compact('category'));
    }


    // account settngs
    function account_settings()
    {
        return view('financial_accounts.account_settings');
    }
}
