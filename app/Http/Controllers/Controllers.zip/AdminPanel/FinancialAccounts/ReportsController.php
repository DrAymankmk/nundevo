<?php

namespace App\Http\Controllers\AdminPanel\FinancialAccounts;

use App\Http\Controllers\Controller;
use App\Models\AccountsTree;
use App\Models\Clinic;
use App\Models\CostCenters;
use App\Models\InsuranceCompanies;
use App\Models\Restrictions;
use App\Models\User;
use Illuminate\Http\Request;

class ReportsController extends Controller
{
    // get ledger
    function ledger(Request $request)
    {
        $data['accounts_tree'] = AccountsTree::where(['account_type'=>3,'clinic_id'=>auth()->user()->parent_id])->latest()->get();
        $data['cost_centers'] = CostCenters::where('clinic_id', auth()->user()->parent_id)->get();
        $query = Restrictions::where('clinic_id',auth()->user()->parent_id);
        if ($request->date_from) {
            $query->whereBetween('created_at', array($request->date_from, $request->date_to));
        }
        if ($request->final_accounts) {
            $query->where('final_accounts',  $request->final_accounts);
        }
        if ($request->cost_id) {
            $query->where('cost_center_id',  $request->cost_id);
        }
        $data['ledgers'] = $query->get();
        return view('financial_accounts.reports.ledger',compact('data'));
    }

    function trial_balance(Request $request)
    {
        $data['accounts_tree'] = AccountsTree::where(['account_type'=>3,'clinic_id'=>auth()->user()->parent_id])->latest()->get();
        $query = Restrictions::where('clinic_id',auth()->user()->parent_id);
        if ($request->date_from) {
            $query->whereBetween('created_at', array($request->date_from, $request->date_to));
        }
        if ($request->final_accounts) {
            $query->where('final_accounts',  $request->final_accounts);
        }
        $data['trial_balance'] = $query->get();
        return view('financial_accounts.reports.trial_balance',compact('data'));
    }

    function trading(Request $request)
    {
        $data['accounts_tree'] = AccountsTree::where(['account_type'=>3,'clinic_id'=>auth()->user()->parent_id])->latest()->get();
        $query = Restrictions::where('clinic_id',auth()->user()->parent_id);
        if ($request->date_from) {
            $query->whereBetween('created_at', array($request->date_from, $request->date_to));
        }
        if ($request->final_accounts) {
            $query->where('final_accounts',  $request->final_accounts);
        }
        $data['trial_balance'] = $query->get();
        return view('financial_accounts.reports.trading',compact('data'));
    }

    function profit_and_loss(Request $request)
    {
        $data['accounts_tree'] = AccountsTree::where(['account_type'=>3,'clinic_id'=>auth()->user()->parent_id])->latest()->get();
        $query = Restrictions::where('clinic_id',auth()->user()->parent_id);
        if ($request->date_from) {
            $query->whereBetween('created_at', array($request->date_from, $request->date_to));
        }
        if ($request->final_accounts) {
            $query->where('final_accounts',  $request->final_accounts);
        }
        $data['trial_balance'] = $query->get();
        return view('financial_accounts.reports.profit_and_loss',compact('data'));
    }

    function financial_position()
    {
        return view('financial_accounts.reports.financial_position');
    }

    function invoices_reports()
    {
        return view('financial_accounts.reports.invoices_reports');
    }

    function income()
    {
        return view('financial_accounts.reports.income');
    }
    function reception_income()
    {
        return view('financial_accounts.reports.reception_income');
    }

    function insurance_claim(Request $request)
    {
        $data['insurances'] = InsuranceCompanies::where(['clinic_id'=>auth()->user()->parent_id])->latest()->get();
        $query = Restrictions::where('clinic_id',auth()->user()->parent_id);
        if ($request->date_from) {
            $query->whereBetween('created_at', array($request->date_from, $request->date_to));
        }
        if ($request->final_accounts) {
            $query->where('final_accounts',  $request->final_accounts);
        }
        $data['trial_balance'] = $query->get();

        return view('financial_accounts.reports.insurance_claim',compact('data'));
    }

    function patients_balance()
    {
        $data['patients'] = User::where('status',1)->latest()->get();
        return view('financial_accounts.reports.patients_balance',compact('data'));
    }

    function doctor_rate()
    {
        $data['doctors'] = Clinic::where(['app_type'=>3,'parent_id'=>auth()->user()->parent_id])->latest()->get();
        return view('financial_accounts.reports.doctor_rate',compact('data'));
    }

    function pharmacist_rate()
    {
        $data['pharmacists'] = Clinic::where(['app_type'=>3,'parent_id'=>auth()->user()->parent_id])->latest()->get();
        return view('financial_accounts.reports.pharmacist_rate',compact('data'));
    }
    function vat_report()
    {
        return view('financial_accounts.reports.vat_report');
    }

    function expenses_vat()
    {
        return view('financial_accounts.reports.expenses_vat');
    }

    function accounts_chart()
    {
        $data['accounts_tree'] = AccountsTree::where(['account_type'=>3,'clinic_id'=>auth()->user()->parent_id])->latest()->get();
        return view('financial_accounts.reports.accounts_chart',compact('data'));
    }

    function salaries()
    {
        return view('financial_accounts.reports.salaries');
    }
}
