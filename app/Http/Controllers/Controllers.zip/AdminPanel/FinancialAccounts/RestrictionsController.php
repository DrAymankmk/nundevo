<?php

namespace App\Http\Controllers\AdminPanel\FinancialAccounts;

use App\Http\Controllers\Controller;
use App\Models\AccountsTree;
use App\Models\DailyEntry;
use App\Models\Restrictions;
use Illuminate\Http\Request;

class RestrictionsController extends Controller
{
    // restriction
    function index()
    {
        $accounts = AccountsTree::where('account_type', 3)->get();
        $restrictions = Restrictions::latest()->get();
        foreach ($restrictions as $restriction) {
            $restriction->daily = DailyEntry::whereId($restriction->daily_entry_id)->first();
        }
        return view('financial_accounts.restrictions', compact('accounts','restrictions'));
    }


    function create_daily_entry(Request $request)
    {
        $data =  $request->all();
        $data['type'] = 1;
        $data['account_id'] = auth()->user()->id;
        $data['clinic_id'] = auth()->user()->parent_id;
        $create_daily = DailyEntry::create($data);
        $i = 0;
        foreach ($request->final_accounts as $category) {
            $added = new Restrictions();
            $added->credit = $request->credit[$i];
            $added->debit = $request->debit[$i];
            $added->daily_entry_id = $create_daily->id;
            $added->final_accounts = $category;
            $added->process = 1;
            $added->reference = $request->reference[$i];
            $added->notice = $request->notice[$i];
            $added->account_type = 1;
            $added->clinic_id = auth()->user()->parent_id;
            $added->account_id = auth()->user()->id;
            $added->save();
            $i++;
        }
        session()->flash('success',trans('admin.added'));
        return redirect()->back();


    }
}
